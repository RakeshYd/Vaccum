﻿using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;
using VaccumeCalculation.DAL;


namespace VaccumeCalculation
{
    public partial class TanksAndPumps : System.Web.UI.Page
    {
        string ProjectID = string.Empty;
        int UserId = 0;
        MainlineData mld = new MainlineData();
        PumpsData pd = new PumpsData();

        protected void Page_Load(object sender, EventArgs e)
        {
            MessageDisplay(false);
            UserDetails("TanksAndPumps");
            if (string.IsNullOrEmpty(ProjectID))
            {
                GetProjectId();
            }



        }
        protected void GetProjectId()
        {

            if (System.Web.HttpContext.Current.Session["ProjectID"] != null)
            {

                ProjectID = Session["ProjectID"].ToString();

            }
            else
            {
                Response.Redirect("Default.aspx");
            }

        }
        protected void GetData()
        {
            PumpsData pmp = new PumpsData();

            DataSet dsData = pmp.GetPumpsData(Convert.ToDouble(txtDflw.Text), Convert.ToDouble(txtDailySew.Text), Convert.ToDouble(txtPower.Text));

            if (dsData != null)
            {
                //lbcdisflwsec.Text = dsData.Tables[0].Rows[0][5].ToString();
                // lblTotalfloss.Text = (Math.Round(Convert.ToDouble(dsData.Tables[0].Rows[0][0]), 2, MidpointRounding.AwayFromZero)).ToString();
                //1st section
                lblPumps.Text = (Math.Round(Convert.ToDouble(dsData.Tables[0].Rows[0][0]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblTotalPumps.Text = (Math.Round(Convert.ToDouble(dsData.Tables[0].Rows[0][1]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblTypesPumps.Text = (Math.Round(Convert.ToDouble(dsData.Tables[0].Rows[0][2]), 2, MidpointRounding.AwayFromZero)).ToString();
                //2nd section
                lblDpumpCapacity.Text = (Math.Round(Convert.ToDouble(dsData.Tables[2].Rows[0][0]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblDpumpCapacitySec.Text = (Math.Round(Convert.ToDouble(dsData.Tables[2].Rows[0][1]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblDPumpPower.Text = (Math.Round(Convert.ToDouble(dsData.Tables[2].Rows[0][2]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblRTPH.Text = (Math.Round(Convert.ToDouble(dsData.Tables[2].Rows[0][3]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblRTPD.Text = (Math.Round(Convert.ToDouble(dsData.Tables[2].Rows[0][4]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblECPD.Text = (Math.Round(Convert.ToDouble(dsData.Tables[2].Rows[0][5]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblSEC.Text = (Math.Round(Convert.ToDouble(dsData.Tables[2].Rows[0][6]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblTSEC.Text = (Math.Round(Convert.ToDouble(dsData.Tables[2].Rows[0][7]), 2, MidpointRounding.AwayFromZero)).ToString();

                //3rd Section

                lblRTPHD.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][0]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblRTPM.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][1]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblStstus.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][2]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblEPHR.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][3]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblECPD_V.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][4]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblVUMLD.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][5]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblRC.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][6]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblVPC_V.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][7]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblVentilator.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][8]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblSECU.Text = (Math.Round(Convert.ToDouble(dsData.Tables[1].Rows[0][9]), 2, MidpointRounding.AwayFromZero)).ToString();


                //4th section
                lblPMVRV.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][0]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblVRTV.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][1]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblCVTV.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][2]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblxtank.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][3]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblVolume.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][4]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblATV.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][2]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblPMSBV.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][3]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblSSVTT.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][4]), 2, MidpointRounding.AwayFromZero)).ToString();


                //5th section
                lblTEM.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][0]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblTPMV.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][1]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblRPeriod.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][2]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblSPeriod.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][3]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblMRTPH.Text = (Math.Round(Convert.ToDouble(dsData.Tables[3].Rows[0][4]), 2, MidpointRounding.AwayFromZero)).ToString();



            }

        }

        protected void calcPumps_Click(object sender, EventArgs e)
        {
            GetData();
        }
        private void UserDetails(string returnURL)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session["UsDetails"] == null)
            {
                Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
            }
            else
            {
                DataSet ds = (DataSet)(Session["UsDetails"]);
                LinkButton btnUser = this.Master.FindControl("loginName") as LinkButton;
                LinkButton btnLogout = this.Master.FindControl("logOut") as LinkButton;
                LinkButton btnLoginLink = this.Master.FindControl("loginLink") as LinkButton;
                if (ds != null && ds.Tables.Count > 0)
                {
                    btnLoginLink.Visible = false;
                    btnUser.Text = "Welcome, " + ds.Tables[0].Rows[0]["FirstName"].ToString() + " !  ";
                    btnUser.Visible = true;
                    btnLogout.Text = "LogOut";
                    btnLogout.Visible = true;
                    UserId = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);


                }
                else
                {
                    Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
                }
            }
        }

        private void GetProject(Int32 userID)
        {
            DataSet dsProject = mld.GetProject(userID);
            ddlProject.DataSource = dsProject.Tables[0];
            ddlProject.DataTextField = "Description";
            ddlProject.DataValueField = "Id";
            ddlProject.DataBind();

        }
        private void MessageDisplay(bool display, string message = "")
        {
            if (display)
            {
                tanksAndPumpseSaveUpdateAlert.InnerText = message.ToString();
                tanksAndPumpseSaveUpdateAlert.Style.Add("display", "block");
            }
            else
            {
                tanksAndPumpseSaveUpdateAlert.Style.Add("display", "none");
            }
        }

        protected void savePumps_Click(object sender, EventArgs e)
        {
            DataSet ds = pd.SaveUpdatePumps(UserId, Convert.ToInt16(ProjectID), Convert.ToDouble(txtDflw.Text), Convert.ToDouble(txtDailySew.Text), Convert.ToDouble(txtPower.Text), Convert.ToDouble(lblPumps.Text), Convert.ToDouble(lblTotalPumps.Text), Convert.ToDouble(lblTypesPumps.Text), Convert.ToDouble(lblDpumpCapacity.Text), Convert.ToDouble(lblDpumpCapacitySec.Text), Convert.ToDouble(lblDPumpPower.Text), Convert.ToDouble(lblRTPH.Text), Convert.ToDouble(lblRTPD.Text),
                                 Convert.ToDouble(lblECPD.Text), Convert.ToDouble(lblSEC.Text), Convert.ToDouble(lblTSEC.Text), Convert.ToDouble(lblRTPD.Text), Convert.ToDouble(lblRTPM.Text), Convert.ToDouble(lblStstus.Text), Convert.ToDouble(lblEPHR.Text), Convert.ToDouble(lblECPD_V.Text), Convert.ToDouble(lblVUMLD.Text), Convert.ToDouble(lblRC.Text), Convert.ToDouble(lblVPC_V.Text), Convert.ToDouble(lblVentilator.Text), Convert.ToDouble(lblSECU.Text), Convert.ToDouble(lblPMVRV.Text), Convert.ToDouble(lblVRTV.Text),
                                 Convert.ToDouble(lblCVTV.Text), Convert.ToDouble(lblxtank.Text), Convert.ToDouble(lblVolume.Text), Convert.ToDouble(lblATV.Text), Convert.ToDouble(lblPMSBV.Text), Convert.ToDouble(lblSSVTT.Text), Convert.ToDouble(lblTEM.Text), Convert.ToDouble(lblTPMV.Text), Convert.ToDouble(lblRPeriod.Text), Convert.ToDouble(lblSPeriod.Text), Convert.ToDouble(lblMRTPH.Text));

            if (ds != null && ds.Tables.Count > 0)
            {
                string message = ds.Tables[0].Rows[0]["Status"].ToString();
                MessageDisplay(true, message);
            }
        }
    }
}