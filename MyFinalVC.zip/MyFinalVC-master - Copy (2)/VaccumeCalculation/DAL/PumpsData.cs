﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VaccumeCalculation.DAL
{
    internal class PumpsData
    {
        internal DataSet GetPumpsData(double peakflw, double dailyflw, double power)
        {

            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_PumpsTank", con);
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.Add("@Qmax", SqlDbType.Float).Value = peakflw;
            cmd.Parameters.Add("@DFlow", SqlDbType.Float).Value = dailyflw;
            cmd.Parameters.Add("@DP_Wt", SqlDbType.Float).Value = power;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        public DataSet SaveUpdatePumps(int userId, int projectId, double txtDflw, double txtDailySew, double txtPower, double lblPumps, double lblTotalPumps, double lblTypesPumps, double lblDpumpCapacity, double lblDpumpCapacitySec, double lblDPumpPower, double lblRTPH, double lblRTPD, double lblECPD, double lblSEC, double lblTSEC, double lblRTPHD, double lblRTPM, double lblStstus, double lblEPHR, double lblECPD_V, double lblVUMLD, double lblRC, double lblVPC_V, double lblVentilator, double lblSECU, double lblPMVRV, double lblVRTV, double lblCVTV, double lblxtank, double lblVolume, double lblATV, double lblPMSBV, double lblSSVTT, double lblTEM, double lblTPMV, double lblRPeriod, double lblSPeriod, double lblMRTPH)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_SaveUpdatePumps", con);
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@projectId", SqlDbType.Int).Value = projectId;
            cmd.Parameters.Add("@txtDflw", SqlDbType.Float).Value = txtDflw;
            cmd.Parameters.Add("@txtDailySew", SqlDbType.Float).Value = txtDailySew;
            cmd.Parameters.Add("@txtPower", SqlDbType.Float).Value = txtPower;
            cmd.Parameters.Add("@lblPumps", SqlDbType.Float).Value = lblPumps;
            cmd.Parameters.Add("@lblTotalPumps", SqlDbType.Float).Value = lblTotalPumps;
            cmd.Parameters.Add("@lblTypesPumps", SqlDbType.Float).Value = lblTypesPumps;
            cmd.Parameters.Add("@lblDpumpCapacity", SqlDbType.Float).Value = lblDpumpCapacity;
            cmd.Parameters.Add("@lblDpumpCapacitySec", SqlDbType.Float).Value = lblDpumpCapacitySec;
            cmd.Parameters.Add("@lblDPumpPower", SqlDbType.Float).Value = lblDPumpPower;
            cmd.Parameters.Add("@lblRTPH", SqlDbType.Float).Value = lblRTPH;

            cmd.Parameters.Add("@lblRTPD", SqlDbType.Float).Value = lblRTPD;
            cmd.Parameters.Add("@lblECPD", SqlDbType.Float).Value = lblECPD;

            cmd.Parameters.Add("@lblSEC", SqlDbType.Float).Value = lblSEC;
            cmd.Parameters.Add("@lblTSEC", SqlDbType.Float).Value = lblTSEC;
            cmd.Parameters.Add("@lblRTPHD", SqlDbType.Float).Value = lblRTPHD;
            cmd.Parameters.Add("@lblRTPM", SqlDbType.Float).Value = lblRTPM;
            cmd.Parameters.Add("@lblStstus", SqlDbType.VarChar).Value = lblStstus;
            cmd.Parameters.Add("@lblEPHR", SqlDbType.Float).Value = lblEPHR;

            cmd.Parameters.Add("@lblECPD_V", SqlDbType.Float).Value = lblECPD_V;
            cmd.Parameters.Add("@lblVUMLD", SqlDbType.Float).Value = lblVUMLD;
            cmd.Parameters.Add("@lblRC", SqlDbType.Float).Value = lblRC;
            cmd.Parameters.Add("@lblVPC_V", SqlDbType.Float).Value = lblVPC_V;
            cmd.Parameters.Add("@lblVentilator", SqlDbType.Float).Value = lblVentilator;
            cmd.Parameters.Add("@lblSECU", SqlDbType.Float).Value = lblSECU;
            cmd.Parameters.Add("@lblPMVRV", SqlDbType.Float).Value = lblPMVRV;
            cmd.Parameters.Add("@lblVRTV", SqlDbType.Float).Value = lblVRTV;
            cmd.Parameters.Add("@lblCVTV", SqlDbType.Float).Value = lblCVTV;
            cmd.Parameters.Add("@lblxtank", SqlDbType.Float).Value = lblxtank;
            cmd.Parameters.Add("@lblVolume", SqlDbType.Float).Value = lblVolume;
            cmd.Parameters.Add("@lblATV", SqlDbType.Float).Value = lblATV;

            cmd.Parameters.Add("@lblPMSBV", SqlDbType.Float).Value = lblPMSBV;
            cmd.Parameters.Add("@lblSSVTT", SqlDbType.Float).Value = lblSSVTT;
            //Last Special values
            cmd.Parameters.Add("@lblTEM", SqlDbType.Float).Value = lblTEM;
            cmd.Parameters.Add("@lblTPMV", SqlDbType.Float).Value = lblTPMV;
            cmd.Parameters.Add("@lblRPeriod", SqlDbType.Float).Value = lblRPeriod;
            cmd.Parameters.Add("@lblSPeriod", SqlDbType.Float).Value = lblSPeriod;
            cmd.Parameters.Add("@lblMRTPH", SqlDbType.Float).Value = lblMRTPH;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }
    }
}