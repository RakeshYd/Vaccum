﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VaccumeCalculation.DAL
{
    public class CalculatePeakFactor
    {
        public DataSet GetPeakFactor(double dailyFlwRate, double quantity)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            
            //SqlCommand cmd = new SqlCommand("USP_GetPeakFactor", con);
            SqlCommand cmd = new SqlCommand("USP_PeakFactorFinal", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@DailyFlwRate", SqlDbType.Int).Value = dailyFlwRate;
            cmd.Parameters.Add("@Quantaty", SqlDbType.Float).Value = quantity;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }


        public DataSet GetPeakValueMax(string Quantaty, string WaterFlow, string PersonPerHouse, string NumberOfHouse, string PeakFactor)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_GetPeakFlowMAX", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@Quantaty", SqlDbType.Int).Value = Quantaty.ToString().Trim();
            cmd.Parameters.Add("@WaterFlow", SqlDbType.VarChar).Value = WaterFlow.ToString().Trim();
            cmd.Parameters.Add("@PersonPerHouse", SqlDbType.Int).Value = PersonPerHouse.ToString().Trim();
            cmd.Parameters.Add("@NumberOfHouse", SqlDbType.VarChar).Value = NumberOfHouse.ToString().Trim();
            cmd.Parameters.Add("@PeakFactor", SqlDbType.VarChar).Value = PeakFactor.ToString().Trim();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }
    }
}