﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VaccumeCalculation.DAL
{
    public class PeakFlowData
    {
        public DataSet SaveUpdatePeakFlowRequest(int UserID, int ProjectID, string peakFlowRequestXML)
        {

            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_SaveUpdatePeakFlowCalculation", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserID", SqlDbType.NVarChar).Value = UserID;
            cmd.Parameters.Add("@ProjectID", SqlDbType.NVarChar).Value = ProjectID;
            cmd.Parameters.Add("@peakFlowXML", SqlDbType.NVarChar).Value = peakFlowRequestXML;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }


        public DataSet GetPeakFlowMax(double Quantaty, double WaterFlow, double PersonPerHouse, double NumberOfHouse, double PeakFactor)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetPeakFlowMAX", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@Quantaty", SqlDbType.VarChar).Value = Quantaty.ToString();
            cmd.Parameters.Add("@WaterFlow", SqlDbType.VarChar).Value = WaterFlow.ToString();
            cmd.Parameters.Add("@PersonPerHouse", SqlDbType.VarChar).Value = PersonPerHouse.ToString();
            cmd.Parameters.Add("@NumberOfHouse", SqlDbType.VarChar).Value = NumberOfHouse.ToString();
            cmd.Parameters.Add("@PeakFactor", SqlDbType.VarChar).Value = PeakFactor.ToString();


            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        internal DataSet GetData(int userId, string peakFlowRowID)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetDataFowRowID", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@PeakFlowRowID", SqlDbType.Int).Value = peakFlowRowID;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }
    }
}