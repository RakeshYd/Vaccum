﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VaccumeCalculation.DAL
{
    public class ProjectData
    {
        public DataSet CreateProject(int UserID, string Project)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("usp_CreateProject", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;
            cmd.Parameters.Add("@Project", SqlDbType.NVarChar).Value = Project.ToString().Trim();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        public DataSet GetNewSession(int UserID)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("usp_NewSession", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = UserID;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

    }
}