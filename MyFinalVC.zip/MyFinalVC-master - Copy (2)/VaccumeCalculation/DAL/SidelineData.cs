﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VaccumeCalculation.DAL
{
    public class SidelineData
    {
        internal DataSet SaveUpdateSidelineRequest(string sidelineRequestXML)
        {

            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_SaveUpdateSidelineRequest", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@SidelineRequestXML", SqlDbType.NVarChar).Value = sidelineRequestXML;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }

        internal DataSet getSidelineData(int projectID, int userId)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_GetSidelineData", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@ProjectID", SqlDbType.NVarChar).Value = projectID;
            cmd.Parameters.Add("@UserId", SqlDbType.NVarChar).Value = userId;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }

        internal DataSet GetDataForUserRowID(int userId, string sideBranchRowID)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_GetDataForUserRowID", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@SideBranchRowID", SqlDbType.Int).Value = sideBranchRowID;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }

        internal DataSet getSidelineDataForUser(int userId, int projectId, string sideLine)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_GetSidelineDataUser", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@ProjectID", SqlDbType.Int).Value = projectId;
            cmd.Parameters.Add("@Sideline", SqlDbType.NVarChar).Value = sideLine;



            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }


        internal DataSet SaveUpdateSublineRequest(string mainlineRequestXML)
        {

            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_SaveUpdateSidelineRequest", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@SideLineRequestXML", SqlDbType.NVarChar).Value = mainlineRequestXML;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }


        public DataSet GetSideLineMaster()
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetSideLineMaster", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }
    }
}