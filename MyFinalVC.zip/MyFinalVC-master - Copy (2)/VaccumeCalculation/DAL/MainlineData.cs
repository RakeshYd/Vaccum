﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VaccumeCalculation.DAL
{
    public class MainlineData
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Len110"></param>
        /// <param name="Len125"></param>
        /// <param name="Len160"></param>
        /// <param name="Len200"></param>
        /// <param name="Len250"></param>
        /// <param name="Flw110"></param>
        /// <param name="Flw125"></param>
        /// <param name="Flw160"></param>
        /// <param name="Flw200"></param>
        /// <param name="Flw250"></param>
        /// <param name="Adl110"></param>
        /// <param name="Adl125"></param>
        /// <param name="Adl160"></param>
        /// <param name="Adl200"></param>
        /// <param name="Adl250"></param>
        /// <returns></returns>
        public DataSet CalculateFrictionLoss(Int32 Len110, Int32 Len125, Int32 Len160, Int32 Len200, Int32 Len250,
            Int32 Flw110, Int32 Flw125, Int32 Flw160, Int32 Flw200, Int32 Flw250,
            Int32 Adl110, Int32 Adl125, Int32 Adl160, Int32 Adl200, Int32 Adl250)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("usp_FrictionLoss", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@Len110", SqlDbType.Float).Value = Convert.ToDouble(Len110);
            cmd.Parameters.Add("@Len125", SqlDbType.Float).Value = Convert.ToDouble(Len125);
            cmd.Parameters.Add("@Len160", SqlDbType.Float).Value = Convert.ToDouble(Len160);
            cmd.Parameters.Add("@Len200", SqlDbType.Float).Value = Convert.ToDouble(Len200);
            cmd.Parameters.Add("@Len250", SqlDbType.Float).Value = Convert.ToDouble(Len250);
            cmd.Parameters.Add("@Flw110", SqlDbType.Float).Value = Convert.ToDouble(Flw110);
            cmd.Parameters.Add("@Flw125", SqlDbType.Float).Value = Convert.ToDouble(Flw125);
            cmd.Parameters.Add("@Flw160", SqlDbType.Float).Value = Convert.ToDouble(Flw160);
            cmd.Parameters.Add("@Flw200", SqlDbType.Float).Value = Convert.ToDouble(Flw200);
            cmd.Parameters.Add("@Flw250", SqlDbType.Float).Value = Convert.ToDouble(Flw250);
            cmd.Parameters.Add("@ADL110", SqlDbType.Float).Value = Convert.ToDouble(Adl110);
            cmd.Parameters.Add("@ADL125", SqlDbType.Float).Value = Convert.ToDouble(Adl125);
            cmd.Parameters.Add("@ADL160", SqlDbType.Float).Value = Convert.ToDouble(Adl160);
            cmd.Parameters.Add("@ADL200", SqlDbType.Float).Value = Convert.ToDouble(Adl200);
            cmd.Parameters.Add("@ADL250", SqlDbType.Float).Value = Convert.ToDouble(Adl250);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        internal DataSet getData(int userId, int mainLineRowID)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_GetMainlineDataUserForRowID", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserId", SqlDbType.NVarChar).Value = userId;
            cmd.Parameters.Add("@MainLineRowID", SqlDbType.NVarChar).Value = mainLineRowID;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;

        }

        internal DataSet GetDashboardForUser(int userId)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetDashboardForUser", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        internal DataSet GetProject(int userID)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetProject", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userID;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="Len110"></param>
        /// <param name="Len125"></param>
        /// <param name="Len160"></param>
        /// <param name="Len200"></param>
        /// <param name="Len250"></param>
        /// <param name="Adl110"></param>
        /// <param name="Adl125"></param>
        /// <param name="Adl160"></param>
        /// <param name="Adl200"></param>
        /// <param name="Adl250"></param>
        /// <returns></returns>
        public DataSet CalculateStaticFrictionLoss(Int32 Len110, Int32 Len125, Int32 Len160, Int32 Len200, Int32 Len250,
                Int32 Adl110, Int32 Adl125, Int32 Adl160, Int32 Adl200, Int32 Adl250)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_StaticLoss", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@Len110", SqlDbType.Float).Value = Convert.ToDouble(Len110);
            cmd.Parameters.Add("@Len125", SqlDbType.Float).Value = Convert.ToDouble(Len125);
            cmd.Parameters.Add("@Len160", SqlDbType.Float).Value = Convert.ToDouble(Len160);
            cmd.Parameters.Add("@Len200", SqlDbType.Float).Value = Convert.ToDouble(Len200);
            cmd.Parameters.Add("@Len250", SqlDbType.Float).Value = Convert.ToDouble(Len250);
            cmd.Parameters.Add("@ADL110", SqlDbType.Float).Value = Convert.ToDouble(Adl110);
            cmd.Parameters.Add("@ADL125", SqlDbType.Float).Value = Convert.ToDouble(Adl125);
            cmd.Parameters.Add("@ADL160", SqlDbType.Float).Value = Convert.ToDouble(Adl160);
            cmd.Parameters.Add("@ADL200", SqlDbType.Float).Value = Convert.ToDouble(Adl200);
            cmd.Parameters.Add("@ADL250", SqlDbType.Float).Value = Convert.ToDouble(Adl250);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        internal DataSet SaveUpdateMainlineRequest(string mainlineRequestXML)
        {

            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_SaveUpdateMainlineRequest", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@MainlineRequestXML", SqlDbType.NVarChar).Value = mainlineRequestXML;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }


        internal DataSet getMainlineData(int projectID, int userId)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_GetMainlineData", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@ProjectID", SqlDbType.NVarChar).Value = projectID;
            cmd.Parameters.Add("@UserId", SqlDbType.NVarChar).Value = userId;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }

        internal DataSet getMainlineDataForUser(int userId, int projectId, int mainline)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_GetMainlineDataUser", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserId", SqlDbType.NVarChar).Value = userId;
            cmd.Parameters.Add("@ProjectID", SqlDbType.NVarChar).Value = projectId;
            cmd.Parameters.Add("@Mainline", SqlDbType.NVarChar).Value = mainline;



            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteNonQuery();
            con.Close();
            return ds;
        }

        public DataSet GetNewDashboardForUser(int userId)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetNewDashboardForUser", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }



    }
}