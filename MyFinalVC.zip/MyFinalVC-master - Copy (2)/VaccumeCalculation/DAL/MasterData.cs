﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VaccumeCalculation.DAL
{
    public class MasterData
    {
        public DataSet GetMainLineMaster()
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetMainLineMaster", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        //public DataSet GetSideLineMaster(int userId, int projectId)
        //{
        //    string str = ConfigurationManager.AppSettings["ConnectionString"];
        //    SqlConnection con = new SqlConnection(str);
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand("USP_GetSideLineMaster", con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = userId;
        //    cmd.Parameters.Add("@ProjectID", SqlDbType.Int).Value = projectId;
        //    SqlDataAdapter da = new SqlDataAdapter(cmd);
        //    DataSet ds = new DataSet();
        //    da.Fill(ds);
        //    cmd.ExecuteReader();
        //    con.Close();
        //    return ds;

        //}
        public DataSet GetPeakFlowData(int userId, int projectId)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetPeakFlowData", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@ProjectID", SqlDbType.Int).Value = projectId;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        public DataSet GetRisingMainData(int userId, int projectId)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetRisingMainData", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@ProjectID", SqlDbType.Int).Value = projectId;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        public DataSet GetCountryMaster()
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetCountryMaster", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        internal DataSet GetAllUsers()
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetAllUsers", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        internal DataSet GetProjectDetails(int projectID)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetProjectDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@ProjectID", SqlDbType.Int).Value = projectID;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        internal DataSet GetAllProject(int userID)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_GetAllProject", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserID", SqlDbType.Int).Value = userID;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }
    }
}
