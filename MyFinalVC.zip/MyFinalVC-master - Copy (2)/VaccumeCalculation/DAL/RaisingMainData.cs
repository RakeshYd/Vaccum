﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VaccumeCalculation.DAL
{
    internal class RaisingMainData
    {
        internal DataSet GetRaisingMainData(double len, double designflow, double capacity, double staticLift)
        {

            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_RISINGMAIN", con);
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.Add("@len", SqlDbType.Float).Value = len;
            cmd.Parameters.Add("@designflow", SqlDbType.Float).Value = designflow;
            cmd.Parameters.Add("@capacity", SqlDbType.Float).Value = capacity;
            cmd.Parameters.Add("@staticLift", SqlDbType.Float).Value = staticLift;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        public DataSet SaveUpdateRisingMain(int userId, int projectId, double txtLen, double txtStaticLft,
            double lblPipeDia, double disFlow, double ddlCapacity, double lblDisFlw, double lbcdisflwsec,
            double geo, double statLift, double lblTotalfloss, double lblTotalHead, double lblVelAvg)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand("USP_SaveUpdateRisingMain", con);
            cmd.CommandType = CommandType.StoredProcedure;


            cmd.Parameters.Add("@userId", SqlDbType.Int).Value = userId;
            cmd.Parameters.Add("@projectId", SqlDbType.Int).Value = projectId;
            cmd.Parameters.Add("@txtLen", SqlDbType.Float).Value = txtLen;
            cmd.Parameters.Add("@txtStaticLft", SqlDbType.Float).Value = txtStaticLft;
            cmd.Parameters.Add("@lblPipeDia", SqlDbType.Float).Value = lblPipeDia;
            cmd.Parameters.Add("@ddlCapacity", SqlDbType.Float).Value = ddlCapacity;
            cmd.Parameters.Add("@lblDisFlw", SqlDbType.Float).Value = lblDisFlw;
            cmd.Parameters.Add("@lbcdisflwsec", SqlDbType.Float).Value = lbcdisflwsec;
            cmd.Parameters.Add("@geo", SqlDbType.Float).Value = geo;
            cmd.Parameters.Add("@statLift", SqlDbType.Float).Value = statLift;
            cmd.Parameters.Add("@lblTotalfloss", SqlDbType.Float).Value = lblTotalfloss;
            cmd.Parameters.Add("@lblTotalHead", SqlDbType.Float).Value = lblTotalHead;
            cmd.Parameters.Add("@lblVelAvg", SqlDbType.Float).Value = lblVelAvg;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }
    }
}