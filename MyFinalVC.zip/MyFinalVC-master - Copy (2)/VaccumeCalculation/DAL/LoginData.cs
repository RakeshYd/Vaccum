﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace VaccumeCalculation.DAL
{
    public class LoginData
    {
        public DataSet GetLogin(string UserName, string Password)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("usp_login", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@UserName", SqlDbType.NVarChar).Value = UserName.ToString().Trim();
            cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = Password.ToString().Trim();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }


        public DataSet SignUp(string fName, string lName, string emailId, string mobileNo, string password, int countryId)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("USP_SignUp", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@FirstName", SqlDbType.NVarChar).Value = fName.ToString().Trim();
            cmd.Parameters.Add("@LastName", SqlDbType.NVarChar).Value = lName.ToString().Trim();

            cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = password.ToString().Trim();
            cmd.Parameters.Add("@EmailId", SqlDbType.NVarChar).Value = emailId.ToString().Trim();

            cmd.Parameters.Add("@MobileNo", SqlDbType.NVarChar).Value = mobileNo.ToString().Trim();
            cmd.Parameters.Add("@CountryId", SqlDbType.Int).Value = countryId;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }

        public DataSet GetMobilePrefixForCountry(int countryID)
        {
            string str = ConfigurationManager.AppSettings["ConnectionString"];
            SqlConnection con = new SqlConnection(str);
            con.Open();

            SqlCommand cmd = new SqlCommand("usp_GetMobilePrefixForCountry", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@CountryID", SqlDbType.Int).Value = countryID;

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            cmd.ExecuteReader();
            con.Close();
            return ds;
        }
    }
}