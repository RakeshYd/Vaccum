﻿using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;
using VaccumeCalculation.DAL;

namespace VaccumeCalculation
{

    public partial class Risingmain : System.Web.UI.Page
    {
        string ProjectID = string.Empty;
        Int32 UserId = 0;
        string RisingMainRowID = string.Empty;
        MasterData md = new MasterData();
        RaisingMainData pd = new RaisingMainData();
        protected void Page_Load(object sender, EventArgs e)
        {
        //    Save.Text = "Save";
           
           
            if (string.IsNullOrEmpty(ProjectID))
            {
                GetProjectId();
            }
            MessageDisplay(false);
            UserDetails("Risingmain");
            if (!IsPostBack)
            {
                if (!string.IsNullOrEmpty(RisingMainRowID))
                {
                    GetRisingMainData(UserId, Convert.ToInt16(RisingMainRowID));
                    Save.Text = "Update";
                }
            }


        }

        private void GetRisingMainData(int userId, int RisingMainRowID)
        {
          //  MasterData md = new MasterData();
            DataSet dsData = md.GetRisingMainData(userId, RisingMainRowID);
            BindData(dsData);
        }
        private void BindData(DataSet dsDataset)
        {
            if (dsDataset != null && dsDataset.Tables[0].Rows.Count > 0)
            {
                txtLen.Text = dsDataset.Tables[0].Rows[0]["txtLen"].ToString();
                lblPipeDia.Text=dsDataset.Tables[0].Rows[0]["lblPipeDia"].ToString();
                ddlCapacity.SelectedValue = dsDataset.Tables[0].Rows[0]["ddlCapacity"].ToString();
                lblDisFlw.Text = dsDataset.Tables[0].Rows[0]["lblDisFlw"].ToString();
                lbcdisflwsec.Text = dsDataset.Tables[0].Rows[0]["lbcdisflwsec"].ToString();
                Geo.Text = dsDataset.Tables[0].Rows[0]["geo"].ToString();
                txtStaticLft.Text = dsDataset.Tables[0].Rows[0]["statLift"].ToString();
                lblDisFlw.Text = dsDataset.Tables[0].Rows[0]["lblTotalfloss"].ToString();
                lbcdisflwsec.Text = dsDataset.Tables[0].Rows[0]["lblTotalHead"].ToString();
                lblVelAvg.Text = dsDataset.Tables[0].Rows[0]["lblVelAvg"].ToString();


            }
            else
            {
                txtLen.Text = "0";
                lblPipeDia.Text = "0";
                ddlCapacity.SelectedValue = "0";
                lblDisFlw.Text = "0";
                lbcdisflwsec.Text = "0";
                Geo.Text = "0";
                txtStaticLft.Text =  "0";
                lblDisFlw.Text =  "0";
                lbcdisflwsec.Text = "0";
                lblVelAvg.Text = "0";

            }
        }

        protected void GetProjectId()
        {

            if (System.Web.HttpContext.Current.Session["ProjectID"] != null)
            {

                ProjectID = Session["ProjectID"].ToString();

            }
            else
            {
                Response.Redirect("Default.aspx");
            }

        }
        private void UserDetails(string returnURL)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session["UsDetails"] == null)
            {
                Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
            }
            else
            {
                DataSet ds = (DataSet)(Session["UsDetails"]);
                LinkButton btnUser = this.Master.FindControl("loginName") as LinkButton;
                LinkButton btnLogout = this.Master.FindControl("logOut") as LinkButton;
                LinkButton btnLoginLink = this.Master.FindControl("loginLink") as LinkButton;
                
                if (HttpContext.Current.Session["RisingMainRowID"] != null)
                {
                    RisingMainRowID = Session["RisingMainRowID"].ToString();
                }

                if (ds != null && ds.Tables.Count > 0)
                {
                    btnLoginLink.Visible = false;
                    btnUser.Text = "Welcome, " + ds.Tables[0].Rows[0]["FirstName"].ToString() + " !  ";
                    btnUser.Visible = true;
                    btnLogout.Text = "LogOut";
                    btnLogout.Visible = true;
                    if (!IsPostBack)
                    {
                        UserId = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);

                    }

                }
                else
                {
                    Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
                }
            }
        }


        protected void StaticLft_TextChanged(object sender, EventArgs e)
        {
            Geo.Text = txtStaticLft.Text;
        }

        protected void GetData()
        {
            RaisingMainData rmd = new RaisingMainData();
            DataSet dsData = rmd.GetRaisingMainData(Convert.ToDouble(txtLen.Text), Convert.ToDouble(DisFlow.Text), Convert.ToDouble(ddlCapacity.SelectedValue), Convert.ToDouble(txtStaticLft.Text));

            if (dsData != null)
            {
                lbcdisflwsec.Text = dsData.Tables[0].Rows[0][5].ToString();
                lblPipeDia.Text = dsData.Tables[0].Rows[0][3].ToString();
                lblDisFlw.Text = dsData.Tables[0].Rows[0][4].ToString();
                lblTotalfloss.Text = (Math.Round(Convert.ToDouble(dsData.Tables[0].Rows[0][0]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblTotalHead.Text = (Math.Round(Convert.ToDouble(dsData.Tables[0].Rows[0][1]), 2, MidpointRounding.AwayFromZero)).ToString();
                lblVelAvg.Text = (Math.Round(Convert.ToDouble(dsData.Tables[0].Rows[0][2]), 2, MidpointRounding.AwayFromZero)).ToString();
            }

        }

        protected void Calculate_Click(object sender, EventArgs e)
        {
            GetData();
        }

        private void SaveData()
        {
            DataSet ds = (DataSet)(Session["UsDetails"]);
            UserId = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);

            RaisingMainData rmd = new RaisingMainData();
            DataSet dsRise = rmd.SaveUpdateRisingMain(UserId, Convert.ToInt32(ProjectID), Convert.ToDouble(txtLen.Text), Convert.ToDouble(txtStaticLft.Text), Convert.ToDouble(lblPipeDia.Text), Convert.ToDouble(DisFlow.Text), Convert.ToDouble(ddlCapacity.Text), Convert.ToDouble(lblDisFlw.Text),
                Convert.ToDouble(lbcdisflwsec.Text), Convert.ToDouble(Geo.Text), Convert.ToDouble(StatLift.Text), Convert.ToDouble(lblTotalfloss.Text), Convert.ToDouble(lblTotalHead.Text), Convert.ToDouble(lblVelAvg.Text));
            if (dsRise != null)
            {
                string message = dsRise.Tables[0].Rows[0]["Status"].ToString();
                MessageDisplay(true, message);
            }
        }

        private void MessageDisplay(bool display, string message = "")
        {
            if (display)
            {
                risingMainSaveUpdateAlert.InnerText = message.ToString();
                risingMainSaveUpdateAlert.Style.Add("display", "block");
            }
            else
            {
                risingMainSaveUpdateAlert.Style.Add("display", "none");
            }
        }


        private void GetProject(Int32 userID)
        {
            MainlineData mld = new MainlineData();
            DataSet dsProject = mld.GetProject(userID);
            ddlProject.DataSource = dsProject.Tables[0];
            ddlProject.DataTextField = "Description";
            ddlProject.DataValueField = "Id";
            ddlProject.DataBind();

        }

        protected void Save_Click(object sender, EventArgs e)
        {
            SaveData();
        }
    }
}