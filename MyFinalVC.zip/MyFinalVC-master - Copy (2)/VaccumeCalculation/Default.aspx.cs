﻿using System;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VaccumeCalculation.DAL;

namespace VaccumeCalculation
{
    public partial class _Default : Page
    {
        Int32 UserId = 0;
        MainlineData mld = new MainlineData();

        protected void Page_Load(object sender, EventArgs e)
        {
            UserDetails("Default");
            if (!IsPostBack)
            {
                GenerateHTML();
            }
        }

        private void UserDetails(string returnURL)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session["UsDetails"] == null)
            {
                //Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
            }
            else
            {
                DataSet ds = (DataSet)(Session["UsDetails"]);
                LinkButton btnUser = this.Master.FindControl("loginName") as LinkButton;
                LinkButton btnLogout = this.Master.FindControl("logOut") as LinkButton;
                LinkButton btnLoginLink = this.Master.FindControl("loginLink") as LinkButton;
                if (ds != null && ds.Tables.Count > 0)
                {
                    btnLoginLink.Visible = false;
                    btnUser.Text = "Welcome, " + ds.Tables[0].Rows[0]["FirstName"].ToString() + " !  ";
                    btnUser.Visible = true;
                    btnLogout.Text = "LogOut";
                    btnLogout.Visible = true;
                    if (!IsPostBack)
                    {
                        UserId = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);
                    }

                }
                else
                {
                    Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
                }
            }
        }

        private void GenerateHTML()
        {
            DataSet dsData = mld.GetNewDashboardForUser(UserId);
            if (dsData != null && dsData.Tables.Count > 0)
            {
                gvControl.DataSource = dsData.Tables[0];
                gvControl.DataBind();
            }

        }

        private void LoadDataInTable(DataTable dt)
        {
            int i = 1;
            //Building an HTML string.
            StringBuilder html = new StringBuilder();

            //add panel
            html.Append("<div class=\"panel panel-default\"> <div class=\"panel-heading\">");

            //heading 
            html.Append("<h4>" + "Dashboard" + "</h4>");

            //heading closed
            html.Append("</div>");

            //body
            html.Append("<div class=\"panel-body\">");

            //Table start.
            html.Append("<table class=\"table table - hover table - striped\" >");

            //Building the Header row.
            html.Append(" <thead>");
            foreach (DataColumn column in dt.Columns)
            {
                html.Append("<th>");
                html.Append(column.ColumnName);
                html.Append("</th>");
            }
            html.Append("</tr></thead>");

            //Building the Data rows.
            foreach (DataRow row in dt.Rows)
            {
                html.Append("<tbody><tr>");
                foreach (DataColumn column in dt.Columns)
                {

                    html.Append("<td>");
                    if (column.ColumnName == "CreateNew")
                    {

                        html.Append(GeneratePlaceHolder(i));
                        i++;
                    }
                    else {
                        html.Append(row[column.ColumnName]);
                    }

                    html.Append("</td>");
                }
                html.Append("</tr></tbody>");
            }

            html.Append("</table>");

            html.Append("</div></div>");

            //Append the HTML string to Placeholder.
            //tablePlaceHolder.Controls.Add(new Literal { Text = html.ToString() });


        }

        protected void btnAsp_Click(object sender, System.EventArgs e)
        {


        }

        private string GeneratePlaceHolder(int i)
        {
            StringBuilder str = new StringBuilder();
            str.Append("<asp:PlaceHolder class=\"btn btn-primary\" ID='btnPlaceHolder" + i.ToString() + "'runat='server' ></asp:PlaceHolder>");
            return str.ToString();
        }

        private void GenerateButtons(int Count)
        {
            dynamic placeHolderName = "";
            for (int i = 1; i <= Count; i++)
            {
                //placeHolderName = ("btnPlaceHolder" + i.ToString());
                //Button btn = new Button();
                //btn.ID = ("btnNew" + i.ToString());
                //btn.Text = "New";
                //btn.Click += new EventHandler(btnAsp_Click);
                //ContentPlaceHolder ctl = (ContentPlaceHolder)Page.FindControl("tablePlaceHolder");
                //PlaceHolder plc = (PlaceHolder)ctl.FindControl(placeHolderName);
                //plc.Controls.Add(btn);
            }

        }

        protected void gvControl_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            int ProjectID = 0;
            if (e.CommandName == "CreateNew")
            {
                ProjectID = Convert.ToInt32(e.CommandArgument);
                AddSession(ProjectID);
                RemoveNavigationSession();
                Response.Redirect("MainlineCalculator.aspx", false);
            }
            if (e.CommandName == "ViewDetails")
            {
                ProjectID = Convert.ToInt32(e.CommandArgument);
                AddSession(ProjectID);
                RemoveNavigationSession();
                Response.Redirect("DetailedDashboard.aspx", false);
            }
        }
        private void AddSession(int projectID)
        {
            if (System.Web.HttpContext.Current.Session["ProjectID"] != null)
            {
                Session.Remove("ProjectID");
                Session["ProjectID"] = projectID.ToString();

            }
            else
            {
                Session["ProjectID"] = projectID.ToString();
            }

        }

        private void RemoveNavigationSession()
        {
            if (System.Web.HttpContext.Current.Session["MainLineRowId"] != null)
            {
                Session.Remove("MainLineRowId");
            }
            if (System.Web.HttpContext.Current.Session["PeakFlowRowId"] != null)
            {
                Session.Remove("PeakFlowRowId");
            }
            if (System.Web.HttpContext.Current.Session["RisingMainRowID"] != null)
            {
                Session.Remove("RisingMainRowID");
            }
            if (System.Web.HttpContext.Current.Session["VacuumStationRowID"] != null)
            {
                Session.Remove("VacuumStationRowID");
            }
            if (System.Web.HttpContext.Current.Session["SideBranchRowID"] != null)
            {
                Session.Remove("SideBranchRowID");
            }
        }
    }
}