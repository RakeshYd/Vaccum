﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using VaccumeCalculation.DAL;

namespace VaccumeCalculation
{
    public partial class SignUp1 : System.Web.UI.Page
    {
        LoginData ld = new LoginData();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                if (!string.IsNullOrEmpty(txtPasswordSignUp.Text))
                {
                    txtPasswordSignUp.Attributes["value"] = txtPasswordSignUp.Text;
                }
                if (!string.IsNullOrEmpty(txtConfirmPassword.Text))
                {
                    txtConfirmPassword.Attributes["value"] = txtConfirmPassword.Text;
                }
            }
            if (!IsPostBack)
            {

                LoadCountry();
            }

        }

        /// <summary>
        /// 
        /// </summary>
        protected void LoadCountry()
        {
            MasterData md = new MasterData();
            DataSet dsCountry = md.GetCountryMaster();
            if (dsCountry.Tables[0].Rows.Count > 0)
            {
                ddlCountry.DataSource = dsCountry.Tables[0];
                ddlCountry.DataTextField = "Description";
                ddlCountry.DataValueField = "Id";
                ddlCountry.DataBind();

                ddlCountry.Items.Insert(0, new ListItem("---Select Country---", "0"));
            }
        }
        /// <summary>
        /// /
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_signup_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt16(ddlCountry.SelectedIndex) > 0)
            {
                signupalert.InnerText = "";
                signupalert.Style.Add("display", "none");

                DataSet dsSignup = ld.SignUp(txtFirstName.Text, txtLastName.Text, txtEmaiAddress.Text, txtMobileNo.Text, txtPasswordSignUp.Text, Convert.ToInt32(ddlCountry.SelectedValue));
                if (dsSignup.Tables[0].Rows.Count > 0)
                {
                    if (dsSignup.Tables[0].Rows[0][0].ToString().ToUpper() == "USER CREATED")
                    {
                        clearFields();
                        signupalert.InnerText = "Sign up successfully, please click on login !";
                        signupalert.Style.Add("display", "block");
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Confirmation", "$(function() { openModal(); });", true);
                    }
                    else
                    {
                        signupalert.InnerText = dsSignup.Tables[0].Rows[0][0].ToString();
                        signupalert.Style.Add("display", "block");
                    }
                }

            }
            else
            {
                signupalert.InnerText = "Please select Country.";
                signupalert.Style.Add("display", "block");
            }


        }

        /// <summary>
        /// 
        /// </summary>
        protected void clearFields()
        {
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtEmaiAddress.Text = "";
            txtMobileNo.Text = "";
            txtPasswordSignUp.Text = "";
            ddlCountry.SelectedIndex = -1;
        }

        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet ds = ld.GetMobilePrefixForCountry(Convert.ToInt16(ddlCountry.SelectedValue));
            if (ds != null && ds.Tables.Count > 0)
            {
                txtPrefix.Text = ds.Tables[0].Rows[0][0].ToString();
            }

        }
    }
}