﻿//using iTextSharp.text.pdf;

using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;
using VaccumeCalculation.DAL;


namespace VaccumeCalculation
{
    public partial class PeakFlowCalculation : System.Web.UI.Page
    {
        string ProjectID = string.Empty;
        Int32 UserId = 0;
        string PeakFlowRowID = string.Empty;
        MasterData md = new MasterData();
        PeakFlowData pd = new PeakFlowData();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ProjectID))
            {
                GetProjectId();
            }
            MessageDisplay(false);
            UserDetails("PeakFlowCalculation");
            if (!IsPostBack)
            {
                //GetProject(UserId);
                if (!string.IsNullOrEmpty(PeakFlowRowID))
                {
                    GetData(UserId, Convert.ToInt16(PeakFlowRowID));
                    btnSave.Text = "Update";
                }
            }

        }

        private void GetData(int userId, short v)
        {
            DataSet ds = pd.GetData(UserId, PeakFlowRowID);
            if (ds != null && ds.Tables.Count > 0)
            {
                BindData(ds);
            }
        }

        protected void GetProjectId()
        {

            if (System.Web.HttpContext.Current.Session["ProjectID"] != null)
            {

                ProjectID = Session["ProjectID"].ToString();

            }
            else
            {
                Response.Redirect("Default.aspx");
            }

        }
        private void UserDetails(string returnURL)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session["UsDetails"] == null)
            {
                Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
            }
            else
            {
                DataSet ds = (DataSet)(Session["UsDetails"]);
                LinkButton btnUser = this.Master.FindControl("loginName") as LinkButton;
                LinkButton btnLogout = this.Master.FindControl("logOut") as LinkButton;
                LinkButton btnLoginLink = this.Master.FindControl("loginLink") as LinkButton;

                if (HttpContext.Current.Session["PeakFlowRowID"] != null)
                {
                    PeakFlowRowID = Session["PeakFlowRowID"].ToString();
                }
                if (ds != null && ds.Tables.Count > 0)
                {
                    btnLoginLink.Visible = false;
                    btnUser.Text = "Welcome, " + ds.Tables[0].Rows[0]["FirstName"].ToString() + " !  ";
                    btnUser.Visible = true;
                    btnLogout.Text = "LogOut";
                    btnLogout.Visible = true;
                    UserId = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);


                }
                else
                {
                    Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
                }
            }
        }


        protected void txtPeakFlow_TextChanged(object sender, EventArgs e)
        {
            DataSet ds = CaluclatePeackingFactor(Convert.ToDouble(txtAverageDailyFlow.Text), Convert.ToDouble(txtPeakFlow.Text));
            if (ds.Tables[0].Rows.Count > 0)
            {

                lblPackingFactor.Text = (Math.Round(Convert.ToDouble(ds.Tables[0].Rows[0][0].ToString()), 2, MidpointRounding.AwayFromZero)).ToString();
                txtPeakFactorInput2.Text = (Math.Round(Convert.ToDouble(ds.Tables[0].Rows[0][0].ToString()), 2, MidpointRounding.AwayFromZero)).ToString();
                lblPeakFlowCalculated2.Text= (Math.Round(Convert.ToDouble(ds.Tables[0].Rows[0][1].ToString()), 2, MidpointRounding.AwayFromZero)).ToString();
            }
            txtPopulationOrPlotsInput2.Text = txtPeakFlow.Text;
           // GEtPeakMax();
        }

        public DataSet CaluclatePeackingFactor(double dailyFlwRate, double quantities)
        {
            CalculatePeakFactor cpf = new CalculatePeakFactor();
            return cpf.GetPeakFactor(dailyFlwRate, quantities);

        }

        protected void txtPeakFactorInput_TextChanged(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds = CalculatePeakFactorValue(Convert.ToString(0), txtAverageFlowReteInput.Text, txtPersonsorHouseInput.Text, txtNoHousesInput.Text, txtPeakFactorInput.Text);

            lblPeakFlowCalucated.Text = (Math.Round(Convert.ToDouble(ds.Tables[0].Rows[0]["PeakFlowMax"].ToString()), 2, MidpointRounding.AwayFromZero)).ToString();
        }

        public DataSet CalculatePeakFactorValue(string Quantaty, string WaterFlow, string PersonPerHouse, string NumberOfHouse, string PeakFactor)
        {
            CalculatePeakFactor cpf = new DAL.CalculatePeakFactor();
            return cpf.GetPeakValueMax(Quantaty, WaterFlow, PersonPerHouse, NumberOfHouse, PeakFactor);
        }

        protected void btnExportPDF_Click(object sender, EventArgs e)
        {

            //DataSet dsData = md.GetPeakFlowData(UserId, Convert.ToInt32(ddlProject.SelectedValue));
            //string html = GenerateHtmlForPDF(dsData.Tables[0]);
            string path = HttpContext.Current.Server.MapPath("~/PeakFlowCalculation.aspx");
            string html = getHTML(path);
            byte[] myStream = PdfSharpConvert(html);
            Response.Clear();
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-length", myStream.Length.ToString());
            Response.BinaryWrite(myStream.ToArray());
            Response.Flush();
            Response.End();
        }


        public byte[] PdfSharpConvert(String html)
        {
            byte[] res = null;
            using (MemoryStream ms = new MemoryStream())
            {
                var pdf = TheArtOfDev.HtmlRenderer.PdfSharp.PdfGenerator.GeneratePdf(html, PdfSharp.PageSize.A4);
                pdf.Save(ms);
                res = ms.ToArray();
            }
            return res;
        }

        //public void PdfConvert(int UserID, int ProjectID)
        //{
        //    string path = HttpContext.Current.Server.MapPath("~/PeakFlowCalculation.aspx");
        //    string input = File.ReadAllText(path);
        //    PdfDocument document = new PdfDocument();
        //    //document.Info.Title = "Peak Flow Calculation";
        //    //document.Info.Author = "Avinash";
        //    //document.Info.Keywords = "Peak Flow Calculation, PDF";
        //    PdfPage page = document.AddPage();
        //    XGraphics gfx = XGraphics.FromPdfPage(page);
        //    XPdfFontOptions options = new XPdfFontOptions(PdfFontEncoding.Unicode, PdfFontEmbedding.Always);
        //    TheArtOfDev.HtmlRenderer.PdfSharp.PdfGenerateConfig pdfconfg = new TheArtOfDev.HtmlRenderer.PdfSharp.PdfGenerateConfig();
        //    pdfconfg.PageSize = PdfSharp.PageSize.A4;
        //    byte[] myStream = PdfSharpConvert(input);
        //    Response.Clear();
        //    Response.ContentType = "application/pdf";
        //    Response.AddHeader("content-length", myStream.Length.ToString());
        //    Response.BinaryWrite(myStream.ToArray());
        //    Response.Flush();
        //    Response.End();
        //    //document.Save("D:\\text\\PeakFlowCalculation.pdf");
        //}

        //public string HtmlInput(string completeHtml)
        //{
        //    Regex regex = new Regex("<div id=\"wanted\">(.*)</strong>");
        //    var v = regex.Match("Unneeded text <strong>Needed Text</strong> More unneeded text");
        //    string s = v.Groups[1].ToString();
        //}

        public void PDF()
        {
            //Response.ContentType = "application/pdf";
            //Response.AddHeader("content-disposition", "attachment;filename=Panel.pdf");
            //Response.Cache.SetCacheability(HttpCacheability.NoCache);

            //StringWriter stringWriter = new StringWriter();
            //HtmlTextWriter htmlTextWriter = new HtmlTextWriter(stringWriter);
            ////printPeakFlowDiv.RenderControl(htmlTextWriter);

            //StringReader stringReader = new StringReader(stringWriter.ToString());
            //Document Doc = new Document(PageSize.A4, 10f, 10f, 100f, 0f);
            //HTMLWorker htmlparser = new HTMLWorker(Doc);
            //PdfWriter.GetInstance(Doc, Response.OutputStream);

            //Doc.Open();
            //htmlparser.Parse(stringReader);
            //Doc.Close();
            //Response.Write(Doc);
            //Response.End();
        }


        public void SaveUpdateData()
        {
            try
            {
                DataSet ds = (DataSet)(Session["UsDetails"]);
                Int16 UserID = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);
                DataSet dsDataXML = new DataSet("root");

                DataTable dtDataXml = new DataTable("tblPeakFlowRequest");

                dtDataXml.Columns.Add(new DataColumn("txtAverageDailyFlow", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ddlPopulation", System.Type.GetType("System.Int64")));
                dtDataXml.Columns.Add(new DataColumn("txtPeakFlow", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("lblPackingFactor", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("txtAverageFlowReteInput", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("txtPersonsorHouseInput", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("lblPeakFlowCalucated", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("txtNoHousesInput", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("txtPeakFactorInput", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("txtAverageDailyFlowInput2", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("txtPopulationOrPlotsInput2", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("lblPeakFlowCalculated2", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("txtPeakFactorInput2", System.Type.GetType("System.Double")));

                DataRow drDataXml = dtDataXml.NewRow();

                drDataXml["txtAverageDailyFlow"] = Convert.ToInt64(txtAverageDailyFlow.Text.Trim());
                drDataXml["ddlPopulation"] = Convert.ToInt32(ddlPopulation.SelectedValue);
                drDataXml["txtPeakFlow"] = Convert.ToDouble(txtPeakFlow.Text.Trim());
                drDataXml["lblPackingFactor"] = Convert.ToDouble(lblPackingFactor.Text.Trim());
                drDataXml["txtAverageFlowReteInput"] = Convert.ToDouble(txtAverageFlowReteInput.Text.Trim());
                drDataXml["txtPersonsorHouseInput"] = Convert.ToDouble(txtPersonsorHouseInput.Text.Trim());
                drDataXml["lblPeakFlowCalucated"] = Convert.ToDouble(lblPeakFlowCalucated.Text.Trim());
                drDataXml["txtNoHousesInput"] = Convert.ToDouble(txtNoHousesInput.Text.Trim());
                drDataXml["txtPeakFactorInput"] = Convert.ToDouble(txtPeakFactorInput.Text.Trim());

                drDataXml["txtAverageDailyFlowInput2"] = Convert.ToDouble(txtAverageDailyFlowInput2.Text.Trim());
                drDataXml["txtPopulationOrPlotsInput2"] = Convert.ToDouble(txtPopulationOrPlotsInput2.Text.Trim());
                drDataXml["lblPeakFlowCalculated2"] = Convert.ToDouble(lblPeakFlowCalculated2.Text.Trim());
                drDataXml["txtPeakFactorInput2"] = Convert.ToDouble(txtPeakFactorInput2.Text.Trim());

                dtDataXml.Rows.Add(drDataXml);
                dsDataXML.Tables.Add(dtDataXml);

                string PeakFlowRequestXML = dsDataXML.GetXml();
                PeakFlowData pd = new PeakFlowData();
                DataSet dsResult = pd.SaveUpdatePeakFlowRequest(UserID, Convert.ToInt32(ProjectID), PeakFlowRequestXML);
                string message = dsResult.Tables[0].Rows[0]["Status"].ToString();
                MessageDisplay(true, message);
            }
            catch (System.Exception ex)
            {
                Session["Exception"] = "Message: " + ex.Message + "~ Stack: " + ex.StackTrace;
                Response.Redirect("DefaultErrorPage.aspx", false);
            }

        }

        public void btnSave_Click(object sender, EventArgs e)
        {
            SaveUpdateData();
        }

        private void MessageDisplay(bool display, string message = "")
        {
            if (display)
            {
                peakFlowSaveUpdateAlert.InnerText = message.ToString();
                peakFlowSaveUpdateAlert.Style.Add("display", "block");
            }
            else
            {
                peakFlowSaveUpdateAlert.Style.Add("display", "none");
            }
        }

        private void GetProject(Int32 userID)
        {
            MainlineData mld = new MainlineData();
            DataSet dsProject = mld.GetProject(userID);
            ddlProject.DataSource = dsProject.Tables[0];
            ddlProject.DataTextField = "Description";
            ddlProject.DataValueField = "Id";
            ddlProject.DataBind();
            ddlProject.Items.Insert(0, new System.Web.UI.WebControls.ListItem("---Select---", "0"));

        }

        protected void ddlProject_SelectedIndexChanged(object sender, EventArgs e)
        {

            GetPeakFlowData(UserId, Convert.ToInt32(ddlProject.SelectedValue));
        }
        private void GetPeakFlowData(int userId, int projectId)
        {
            MasterData md = new MasterData();
            DataSet dsData = md.GetPeakFlowData(userId, projectId);
            BindData(dsData);
        }

        private void BindData(DataSet dsData)
        {
            if (dsData != null && dsData.Tables[0].Rows.Count > 0)
            {
                txtAverageDailyFlow.Text = dsData.Tables[0].Rows[0]["txtAverageDailyFlow"].ToString();
                ddlPopulation.SelectedValue = dsData.Tables[0].Rows[0]["ddlPopulation"].ToString();
                txtPeakFlow.Text = dsData.Tables[0].Rows[0]["txtPeakFlow"].ToString();
                lblPackingFactor.Text = dsData.Tables[0].Rows[0]["lblPackingFactor"].ToString();
                txtAverageFlowReteInput.Text = dsData.Tables[0].Rows[0]["txtAverageFlowReteInput"].ToString();
                txtPersonsorHouseInput.Text = dsData.Tables[0].Rows[0]["txtPersonsorHouseInput"].ToString();
                lblPeakFlowCalucated.Text = dsData.Tables[0].Rows[0]["lblPeakFlowCalucated"].ToString();
                txtNoHousesInput.Text = dsData.Tables[0].Rows[0]["txtNoHousesInput"].ToString();
                txtPeakFactorInput.Text = dsData.Tables[0].Rows[0]["txtPeakFactorInput"].ToString();
                txtAverageDailyFlowInput2.Text = dsData.Tables[0].Rows[0]["txtAverageDailyFlowInput2"].ToString();
                txtPopulationOrPlotsInput2.Text = dsData.Tables[0].Rows[0]["txtPopulationOrPlotsInput2"].ToString();
                lblPeakFlowCalculated2.Text = dsData.Tables[0].Rows[0]["lblPeakFlowCalculated2"].ToString();
                txtPeakFactorInput2.Text = dsData.Tables[0].Rows[0]["txtPeakFactorInput2"].ToString();
            }
            else
            {
                txtAverageDailyFlow.Text = "0";
                ddlPopulation.SelectedValue = "1";
                txtPeakFlow.Text = "0";
                lblPackingFactor.Text = "0";
                txtAverageFlowReteInput.Text = "0";
                txtPersonsorHouseInput.Text = "0";
                lblPeakFlowCalucated.Text = "0";
                txtNoHousesInput.Text = "0";
                txtPeakFactorInput.Text = "0";
                txtAverageDailyFlowInput2.Text = "0";
                txtPopulationOrPlotsInput2.Text = "0";
                lblPeakFlowCalculated2.Text = "0";
                txtPeakFactorInput2.Text = "0";
            }
        }

        private string getHTML(string currentPageUrl)
        {
            WebClient myClient = new WebClient();
            string myPageHTML = null;
            byte[] requestHTML;

            UTF8Encoding utf8 = new UTF8Encoding();

            requestHTML = myClient.DownloadData(currentPageUrl);

            myPageHTML = utf8.GetString(requestHTML);

            //Response.Write(myPageHTML);

            return myPageHTML;

        }

        protected void txtAverageDailyFlow_TextChanged(object sender, EventArgs e)
        {
            txtAverageDailyFlowInput2.Text = txtAverageDailyFlow.Text;

        }

        //public string GenerateHtmlForPDF(DataTable dtRawData)
        //{

        //    //StringBuilder sb = new StringBuilder();
        //    //sb.Append("<html>< body >");
        //    //sb.Append("<div style=\"border: 1px solid black; padding: 5px\">< div style = \"background-color: lightgray; padding-left: 10px;\" >");
        //    //sb.Append("< h1 >< span style = \"font-weight: bolder; vertical-align: middle;\" >< span style = \"color: red\" > (FREE) </ span >< span style = \"color: black\" > P </ span >< span style = \"color: blue\" > eak </ span >< span style = \"color: black\" > F </ span >< span style = \"color: blue\" > low </ span >< span style = \"color: black\" > C </ span >< span style = \"color: blue\" > alculator </ span ></ span ></ h1 >");
        //    //sb.Append(" </ div >< div >< p > All of the major vacuum system components are sized according to peak flow, expressed in liters per minute(L / min) or gallons per minute (G / min).Peak flow rates are calculated by applying a peaking factor to an average daily flow rate.</ p >");
        //    //sb.Append("< span style = \"color: lightblue\" > Average Daily Flow </ span >< br /> Sewage flow rates are based on one of the following:< ol > < li > Documented wastewater flow for the area being served.Water use records are typically used for this purpose.</ li >< li > ");
        //    //sb.Append(Convert.ToString(dtRawData.Rows[0]["txtAverageDailyFlow"].ToString()) + " liters per person per day combined with home population densities specific to the service area.</li></ ol > ");
        //    //sb.Append("<span style=\"color: lightblue\">Peaking Factor (PF)</span><br /> The Peaking Factor suggested by the design firm should be used, with one exception: < br /> < b > the minimum peaking factor should never be less than 2, 5.</ b >< br />");
        //    //sb.Append("If not established by the consulting firm, regulatory agency or other applicable regulations, the peaking factor will be calculated when you fill in the population or plots in the < span style = \"color: forestgreen\" > GREEN </ span > field in the Peak Flow Calculator. < br /> < b > If you want to calculate the Peak Factor yourself, please fill in the needed information: </ b > ");
        //    //sb.Append("Population : " + dtRawData.Rows[0]["ddlPopulation"].ToString() + " " + dtRawData.Rows[0]["txtPeakFlow"].ToString() + " Qty.");
        //    //sb.Append("<h2><span style=\"color: lightgreen; padding - left: 125px; \">The Peaking Factor is </span>" + dtRawData.Rows[0]["lblPackingFactor"].ToString());
        //    //sb.Append("<span style=\"color: lightblue\">Peak Flow (Qmax)</span><br /> Applying the Peak Factor to the average daily flow rate and converting to L / min will yield the peak flow to be used as the basis of the design.< br /> < br /> 1.If the design firm provides the average daily flow based on local water records and recommends a peaking factor, both should be used as the basis for design.In this case fill in the following GREEN fields:");
        //    //sb.Append(" <div>< div > Average Daily Flow Rate " + dtRawData.Rows[0]["txtAverageFlowReteInput"].ToString() + "</ div >< div > Persons / House" + dtRawData.Rows[0]["txtPersonsorHouseInput"].ToString());
        //    //sb.Append("<div style=\"float: right\">< h4 >< span style = \"color: lightgreen\" > Peak Flow(Qmax) is </ span >" + dtRawData.Rows[0]["lblPeakFlowCalucated"].ToString() + "</h4></ div ></ div >< div > # Houses " + dtRawData.Rows[0]["txtNoHousesInput"].ToString());
        //    //sb.Append("</div>< div > Peak Factor " + dtRawData.Rows[0]["txtPeakFactorInput"].ToString() + "</div></ div >< br /> 2.If the design does not suggest average daily flow rates and peaking factors, then the Peak Flow should be used after filling in the requested data for determing the Peaking Factor.< div >< div > Average daily flow rate");
        //    //sb.Append(dtRawData.Rows[0]["txtAverageDailyFlowInput2"].ToString() + "</div>< div > Population / Plots " + dtRawData.Rows[0]["txtPopulationOrPlotsInput2"].ToString());
        //    //sb.Append("< div style = \"float: right\" >< h4 >< span style = \"color: lightgreen\" > Peak Flow(Qmax) is</ span >" + dtRawData.Rows[0]["lblPeakFlowCalculated2"].ToString());
        //    //sb.Append("</h4></ div ></ div >< div > Peak Factor " + dtRawData.Rows[0]["txtPeakFactorInput2"].ToString() + " </div></ div ></ div ></ div ></body></html>");
        //    //return Server.HtmlDecode(sb.ToString());

        //}

        //public void GEtPeakMax()
        //{
        //    DataSet ds = pd.GetPeakFlowMax(Convert.ToDouble(txtAverageDailyFlow.Text), Convert.ToDouble(txtAverageDailyFlowInput2.Text), Convert.ToDouble(txtPopulationOrPlotsInput2.Text), Convert.ToDouble(txtPeakFlow.Text), Convert.ToDouble(txtPeakFactorInput2.Text));
        //    if (ds != null && ds.Tables.Count > 0)
        //    {
        //        lblPeakFlowCalculated2.Text = (Math.Round(Convert.ToDouble(ds.Tables[0].Rows[0][0].ToString()), 2, MidpointRounding.AwayFromZero)).ToString();

        //    }
        //}

    }
}