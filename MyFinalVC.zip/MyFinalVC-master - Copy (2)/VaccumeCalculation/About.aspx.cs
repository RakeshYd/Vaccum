﻿using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace VaccumeCalculation
{
    public partial class About : Page
    {
        Int32 UserId = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserDetails("About");
        }

        private void UserDetails(string returnURL)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session["UsDetails"] == null)
            {
                Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
            }
            else
            {
                DataSet ds = (DataSet)(Session["UsDetails"]);
                LinkButton btnUser = this.Master.FindControl("loginName") as LinkButton;
                LinkButton btnLogout = this.Master.FindControl("logOut") as LinkButton;
                LinkButton btnLoginLink = this.Master.FindControl("loginLink") as LinkButton;
                if (ds != null && ds.Tables.Count > 0)
                {
                    btnLoginLink.Visible = false;
                    btnUser.Text = "Welcome, " + ds.Tables[0].Rows[0]["FirstName"].ToString() + " !  ";
                    btnUser.Visible = true;
                    btnLogout.Text = "LogOut";
                    btnLogout.Visible = true;
                    if (!IsPostBack)
                    {
                        UserId = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);
                    }

                }
                else
                {
                    Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
                }
            }
        }

    }
}