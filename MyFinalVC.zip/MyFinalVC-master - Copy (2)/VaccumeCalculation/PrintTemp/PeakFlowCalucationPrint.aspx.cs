﻿using System;
using System.Data;
using VaccumeCalculation.DAL;

namespace VaccumeCalculation.PrintTemp
{
    public partial class PeakFlowCalucationPrint : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetPeakFlowData(Convert.ToInt32(Request.QueryString["UserID"]), Convert.ToInt32(Request.QueryString["ProjectID"]));
        }

        private void GetPeakFlowData(int userId, int projectId)
        {
            MasterData md = new MasterData();
            DataSet dsData = md.GetPeakFlowData(userId, projectId);
            txtAverageDailyFlow.Text = dsData.Tables[0].Rows[0]["txtAverageDailyFlow"].ToString();
            txtPopulation.Text = dsData.Tables[0].Rows[0]["ddlPopulation"].ToString();
            txtPeakFlow.Text = dsData.Tables[0].Rows[0]["txtPeakFlow"].ToString();
            lblPackingFactor.Text = dsData.Tables[0].Rows[0]["lblPackingFactor"].ToString();
            txtAverageFlowReteInput.Text = dsData.Tables[0].Rows[0]["txtAverageFlowReteInput"].ToString();
            txtPersonsorHouseInput.Text = dsData.Tables[0].Rows[0]["txtPersonsorHouseInput"].ToString();
            lblPeakFlowCalucated.Text = dsData.Tables[0].Rows[0]["lblPeakFlowCalucated"].ToString();
            txtNoHousesInput.Text = dsData.Tables[0].Rows[0]["txtNoHousesInput"].ToString();
            txtPeakFactorInput.Text = dsData.Tables[0].Rows[0]["txtPeakFactorInput"].ToString();
            txtAverageDailyFlowInput2.Text = dsData.Tables[0].Rows[0]["txtAverageDailyFlowInput2"].ToString();
            txtPopulationOrPlotsInput2.Text = dsData.Tables[0].Rows[0]["txtPopulationOrPlotsInput2"].ToString();
            lblPeakFlowCalculated2.Text = dsData.Tables[0].Rows[0]["lblPeakFlowCalculated2"].ToString();
            txtPeakFactorInput2.Text = dsData.Tables[0].Rows[0]["txtPeakFactorInput2"].ToString();

        }
    }

}