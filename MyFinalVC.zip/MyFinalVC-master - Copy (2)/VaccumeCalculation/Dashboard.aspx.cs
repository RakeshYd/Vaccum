﻿using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;
using VaccumeCalculation.DAL;

namespace VaccumeCalculation
{
    public partial class Dashboard : System.Web.UI.Page
    {
        private readonly string htmlDashboard = "<div class=\"col-xs-12 col-md-3\"><div class=\"avi-summary-block avi-summary-block-primary\"><div class=\"summary-background\"><i class=\"glyphicon glyphicon-folder-open\"></i></div> <div class=\"summary-body\"> <div class=\"summary-line1\"> {0} </div><div class=\"summary-line2\"> {1} </div> </div><div class=\"summary-footer\"> <a href=\"DetailedDashboard.aspx?ProjId={2}\">Click Here <i class=\"glyphicon glyphicon-chevron-right pull-right\"></i></a></div> </div></div>";
        int UserId = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserDetails("Dashboard");
            GenerateSummaryBlock();
        }

        private void UserDetails(string returnURL)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session["UsDetails"] == null)
            {
                Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
            }
            else
            {
                DataSet ds = (DataSet)(Session["UsDetails"]);
                LinkButton btnUser = this.Master.FindControl("loginName") as LinkButton;
                LinkButton btnLogout = this.Master.FindControl("logOut") as LinkButton;
                LinkButton btnLoginLink = this.Master.FindControl("loginLink") as LinkButton;
                if (ds != null && ds.Tables.Count > 0)
                {
                    btnLoginLink.Visible = false;
                    btnUser.Text = "Welcome, " + ds.Tables[0].Rows[0]["FirstName"].ToString() + " !  ";
                    btnUser.Visible = true;
                    btnLogout.Text = "LogOut";
                    btnLogout.Visible = true;
                    if (!IsPostBack)
                    {
                        UserId = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);
                    }

                }
                else
                {
                    Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
                }
            }
        }


        private void GenerateSummaryBlock()
        {
            MainlineData md = new MainlineData();
            DataSet dsDashboard = md.GetDashboardForUser(UserId);
            GenerateHTML(dsDashboard.Tables[0]);
        }

        private void GenerateHTML(DataTable dtData)
        {
            for (int i = 0; i < dtData.Rows.Count; i++)
            {
                DashboardDiv.InnerHtml += string.Format(htmlDashboard, dtData.Rows[i][0].ToString(), dtData.Rows[i][1].ToString(), dtData.Rows[i][2].ToString());
            }
        }
    }
}