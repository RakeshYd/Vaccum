﻿using System;
using System.Web.UI;

namespace VaccumeCalculation
{
    public partial class SiteMaster : MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Unnamed_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("~/Logout.aspx");
        }

        protected void loginLink_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/login.aspx");
        }
    }
}