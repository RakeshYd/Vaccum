﻿using System;
using System.Data;
using System.Web;
using VaccumeCalculation.DAL;

namespace VaccumeCalculation
{
    public partial class Project : System.Web.UI.Page
    {
        Int32 UserId = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            UserDetails("Project");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="returnURL"></param>
        private void UserDetails(string returnURL)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session["UsDetails"] == null)
            {
                Response.Redirect("~/login.aspx");
            }
            else
            {

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            project_alert.InnerText = "";
            DataSet ds = (DataSet)(Session["UsDetails"]);
            UserId = Convert.ToInt32(ds.Tables[0].Rows[0]["UserId"]);
            project_alert.Style.Add("display", "none");
            if (CreateProject(UserId, txtProject.Text.Trim()))
            {
                Response.Redirect("~/Default.aspx");
            }
            else
            {
                project_alert.InnerText = "Please try with other project name.";
                project_alert.Style.Add("display", "block");
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="project"></param>
        /// <returns></returns>
        private bool CreateProject(int userID, string project)
        {
            bool status = false;
            ProjectData pd = new ProjectData();
            DataSet dsResult = pd.CreateProject(userID, project);
            if (dsResult.Tables[0].Rows.Count > 0)
            {
                status = true;
            }
            else
            {
                status = false;
            }
            return status;

        }
    }
}