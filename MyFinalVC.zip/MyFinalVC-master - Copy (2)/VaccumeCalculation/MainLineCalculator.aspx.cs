﻿using System;
using System.Data;
using System.Web;
using System.Web.UI.WebControls;
using VaccumeCalculation.DAL;

namespace VaccumeCalculation
{
    public partial class MainLineCalculator : System.Web.UI.Page
    {
        Int32 UserId = 0;
        string ProjectID = string.Empty;
        string MainLineRowID = string.Empty;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        MasterData md = new MasterData();
        MainlineData mld = new MainlineData();
        protected void Page_Load(object sender, EventArgs e)
        {
            btnSave.Text = "Save";
            MessageDisplay(false);
            UserDetails("MainLineCalculator");
            if (string.IsNullOrEmpty(ProjectID))
            {
                GetProjectId();

            }

            if (!IsPostBack)
            {
                GetMainLineMaster();
                if (!string.IsNullOrEmpty(MainLineRowID))
                {
                    GetData(UserId, Convert.ToInt16(MainLineRowID));
                    btnSave.Text = "Update";
                }

            }


        }

        private void GetData(int UserID, int MainLineRowID)
        {
            DataSet ds = mld.getData(UserID, MainLineRowID);
            if (ds != null && ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddlMainLine.SelectedValue = ds.Tables[0].Rows[0][3].ToString();
                    txtLength.Text = ds.Tables[0].Rows[0][4].ToString();
                    txtLength_TextChanged("", null);
                    len110.Text = ds.Tables[0].Rows[0][5].ToString();
                    len110_TextChanged("", null);
                    flw110.Text = ds.Tables[0].Rows[0][6].ToString();
                    adl110.Text = ds.Tables[0].Rows[0][7].ToString();
                    pl110.Text = ds.Tables[0].Rows[0][8].ToString();
                    ca110.Text = ds.Tables[0].Rows[0][9].ToString();
                    ce110.Text = ds.Tables[0].Rows[0][10].ToString();
                    plt110.Text = ds.Tables[0].Rows[0][11].ToString();
                    len125.Text = ds.Tables[0].Rows[0][12].ToString();
                    len125_TextChanged("", null);
                    flw125.Text = ds.Tables[0].Rows[0][13].ToString();
                    adl125.Text = ds.Tables[0].Rows[0][14].ToString();
                    pl125.Text = ds.Tables[0].Rows[0][15].ToString();
                    ca125.Text = ds.Tables[0].Rows[0][16].ToString();
                    ce125.Text = ds.Tables[0].Rows[0][17].ToString();
                    plt125.Text = ds.Tables[0].Rows[0][18].ToString();
                    len160.Text = ds.Tables[0].Rows[0][19].ToString();
                    len160_TextChanged("", null);
                    flw160.Text = ds.Tables[0].Rows[0][20].ToString();
                    adl160.Text = ds.Tables[0].Rows[0][21].ToString();
                    pl160.Text = ds.Tables[0].Rows[0][22].ToString();
                    ca160.Text = ds.Tables[0].Rows[0][23].ToString();
                    ce160.Text = ds.Tables[0].Rows[0][24].ToString();
                    plt160.Text = ds.Tables[0].Rows[0][25].ToString();
                    len200.Text = ds.Tables[0].Rows[0][26].ToString();
                    len200_TextChanged("", null);
                    flw200.Text = ds.Tables[0].Rows[0][27].ToString();
                    adl200.Text = ds.Tables[0].Rows[0][28].ToString();
                    pl200.Text = ds.Tables[0].Rows[0][29].ToString();
                    ca200.Text = ds.Tables[0].Rows[0][30].ToString();
                    ce200.Text = ds.Tables[0].Rows[0][31].ToString();
                    plt200.Text = ds.Tables[0].Rows[0][32].ToString();
                    len250.Text = ds.Tables[0].Rows[0][33].ToString();
                    len125_TextChanged("", null);
                    flw250.Text = ds.Tables[0].Rows[0][34].ToString();
                    adl250.Text = ds.Tables[0].Rows[0][35].ToString();
                    pl250.Text = ds.Tables[0].Rows[0][36].ToString();
                    ca250.Text = ds.Tables[0].Rows[0][37].ToString();
                    ce250.Text = ds.Tables[0].Rows[0][38].ToString();
                    plt250.Text = ds.Tables[0].Rows[0][39].ToString();
                    lblFrictionLoss.Text = ds.Tables[0].Rows[0][40].ToString();
                    lblStaticFrictionLoss.Text = ds.Tables[0].Rows[0][41].ToString();
                }
                else
                {





                    txtLength.Text = "0";
                    len110.Text = "0";
                    len110_TextChanged("", null);
                    flw110.Text = "0";
                    adl110.Text = "0";
                    pl110.Text = "0";
                    ca110.Text = "0";
                    ce110.Text = "0";
                    plt110.Text = "0";
                    len125.Text = "0";
                    len125_TextChanged("", null);
                    flw125.Text = "0";
                    adl125.Text = "0";
                    pl125.Text = "0";
                    ca125.Text = "0";
                    ce125.Text = "0";
                    plt125.Text = "0";
                    len160.Text = "0";
                    len160_TextChanged("", null);
                    flw160.Text = "0";
                    adl160.Text = "0";
                    pl160.Text = "0";
                    ca160.Text = "0";
                    ce160.Text = "0";
                    plt160.Text = "0";
                    len200.Text = "0";
                    len200_TextChanged("", null);
                    flw200.Text = "0";
                    adl200.Text = "0";
                    pl200.Text = "0";
                    ca200.Text = "0";
                    ce200.Text = "0";
                    plt200.Text = "0";
                    len250.Text = "0";
                    len250_TextChanged("", null);
                    flw250.Text = "0";
                    adl250.Text = "0";
                    pl250.Text = "0";
                    ca250.Text = "0";
                    ce250.Text = "0";
                    plt250.Text = "0";
                    lblFrictionLoss.Text = "0";
                    lblStaticFrictionLoss.Text = "0";
                    ResetField();
                }
            }
        }

        private void UserDetails(string returnURL)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session["UsDetails"] == null)
            {
                Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
            }
            else
            {
                DataSet ds = (DataSet)(Session["UsDetails"]);
                LinkButton btnUser = this.Master.FindControl("loginName") as LinkButton;
                LinkButton btnLogout = this.Master.FindControl("logOut") as LinkButton;
                LinkButton btnLoginLink = this.Master.FindControl("loginLink") as LinkButton;
                if (HttpContext.Current.Session["MainLineRowID"] != null)
                {
                    MainLineRowID = Session["MainLineRowID"].ToString();
                }

                if (ds != null && ds.Tables.Count > 0)
                {
                    btnLoginLink.Visible = false;
                    btnUser.Text = "Welcome, " + ds.Tables[0].Rows[0]["FirstName"].ToString() + " !  ";
                    btnUser.Visible = true;
                    btnLogout.Text = "LogOut";
                    btnLogout.Visible = true;
                    UserId = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);

                }
                else
                {
                    Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
                }
            }
        }

        private void GetProject(Int32 userID)
        {
            DataSet dsProject = mld.GetProject(userID);
            ddlProject.DataSource = dsProject.Tables[0];
            ddlProject.DataTextField = "Description";
            ddlProject.DataValueField = "Id";
            ddlProject.DataBind();

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="txtLengthVal"></param>
        public void setData(string txtLengthVal)
        {
            txtLength.Text = txtLengthVal;
            tl110.Text = txtLengthVal;
            tl125.Text = txtLengthVal;
            tl160.Text = txtLengthVal;
            tl200.Text = txtLengthVal;
            tl250.Text = txtLengthVal;

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        protected void txtLength_TextChanged(object sender, EventArgs e)
        {
            Int32 flag;
            Int32.TryParse(txtLength.Text, out flag);
            if (flag != 0)
            {
                tl110.Text = txtLength.Text;
                tl125.Text = txtLength.Text;
                tl160.Text = txtLength.Text;
                tl200.Text = txtLength.Text;
                tl250.Text = txtLength.Text;
            }
            else
            {

                errorMsg.Visible = true;
            }
        }

        /// <summary>
        /// /
        /// </summary>
        protected void GetMainLineMaster()
        {

            DataSet dsMainline = md.GetMainLineMaster();
            ddlMainLine.DataSource = dsMainline.Tables[0];
            ddlMainLine.DataTextField = "Description";
            ddlMainLine.DataValueField = "Id";
            ddlMainLine.DataBind();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void len110_TextChanged(object sender, EventArgs e)
        {
            Int32 flag;
            Int32.TryParse(len110.Text, out flag);
            if (flag != 0)
            {
                tl110.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - Convert.ToInt32(len110.Text));
                tl125.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text)));
                tl160.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text)));
                tl200.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text) + Convert.ToInt32(len200.Text)));
                tl250.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text) + Convert.ToInt32(len200.Text) + Convert.ToInt32(len250.Text)));
            }
            else
            {

                errorMsg.Visible = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void len125_TextChanged(object sender, EventArgs e)
        {
            len110_TextChanged(sender, e);
            Int32 flag;
            Int32.TryParse(len125.Text, out flag);
            if (flag != 0)
            {
                tl125.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text)));
                tl160.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text)));
                tl200.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text) + Convert.ToInt32(len200.Text)));
                tl250.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text) + Convert.ToInt32(len200.Text) + Convert.ToInt32(len250.Text)));
            }
            else
            {

                errorMsg.Visible = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void len160_TextChanged(object sender, EventArgs e)
        {
            len110_TextChanged(sender, e);
            len125_TextChanged(sender, e);
            Int32 flag;
            Int32.TryParse(len160.Text, out flag);
            if (flag != 0)
            {
                tl160.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text)));
                tl200.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text) + Convert.ToInt32(len200.Text)));
                tl250.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text) + Convert.ToInt32(len200.Text) + Convert.ToInt32(len250.Text)));
            }
            else
            {

                errorMsg.Visible = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void len200_TextChanged(object sender, EventArgs e)
        {
            len110_TextChanged(sender, e);
            len125_TextChanged(sender, e);
            len160_TextChanged(sender, e);
            Int32 flag;
            Int32.TryParse(len200.Text, out flag);
            if (flag != 0)
            {
                tl200.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text) + Convert.ToInt32(len200.Text)));
                tl250.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text) + Convert.ToInt32(len200.Text) + Convert.ToInt32(len250.Text)));
            }
            else
            {

                errorMsg.Visible = true;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void len250_TextChanged(object sender, EventArgs e)
        {
            len110_TextChanged(sender, e);
            len125_TextChanged(sender, e);
            len160_TextChanged(sender, e);
            len200_TextChanged(sender, e);
            Int32 flag;
            Int32.TryParse(len250.Text, out flag);
            if (flag != 0)
            {
                tl250.Text = Convert.ToString(Convert.ToInt32(txtLength.Text) - (Convert.ToInt32(len110.Text) + Convert.ToInt32(len125.Text) + Convert.ToInt32(len160.Text) + Convert.ToInt32(len200.Text) + Convert.ToInt32(len250.Text)));
            }
            else
            {

                errorMsg.Visible = true;
            }
        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {

            DataSet dsFriction = mld.CalculateFrictionLoss(Convert.ToInt32(len110.Text), Convert.ToInt32(len125.Text), Convert.ToInt32(len160.Text), Convert.ToInt32(len200.Text),
                Convert.ToInt32(len250.Text), Convert.ToInt32(flw110.Text), Convert.ToInt32(flw125.Text), Convert.ToInt32(flw160.Text), Convert.ToInt32(flw200.Text), Convert.ToInt32(flw250.Text), Convert.ToInt32(adl110.Text),
                Convert.ToInt32(adl125.Text), Convert.ToInt32(adl160.Text), Convert.ToInt32(adl200.Text), Convert.ToInt32(adl250.Text));

            DataSet dsStatic = mld.CalculateStaticFrictionLoss(Convert.ToInt32(len110.Text), Convert.ToInt32(len125.Text), Convert.ToInt32(len160.Text), Convert.ToInt32(len200.Text), Convert.ToInt32(len250.Text),
                Convert.ToInt32(adl110.Text), Convert.ToInt32(adl125.Text), Convert.ToInt32(adl160.Text), Convert.ToInt32(adl200.Text), Convert.ToInt32(adl250.Text));

            if (dsFriction.Tables[0].Rows.Count > 0 && dsStatic.Tables[0].Rows.Count > 0)
            {
                lblFrictionLoss.Text = (Math.Round(Convert.ToDouble(dsFriction.Tables[0].Rows[0][0]), 2)).ToString();
                lblStaticFrictionLoss.Text = Math.Round(Convert.ToDouble(dsStatic.Tables[0].Rows[0][0]), 2).ToString();
            }

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            try
            {

                DataSet dsDataXML = new DataSet("root");
                DataTable dtDataXml = new DataTable("tblMainlineRequest");

                dtDataXml.Columns.Add(new DataColumn("userId", System.Type.GetType("System.Int64")));
                dtDataXml.Columns.Add(new DataColumn("ddlProject", System.Type.GetType("System.Int64")));
                dtDataXml.Columns.Add(new DataColumn("ddlMainLine", System.Type.GetType("System.Int64")));
                dtDataXml.Columns.Add(new DataColumn("txtLength", System.Type.GetType("System.Double")));

                dtDataXml.Columns.Add(new DataColumn("len110", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("flw110", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("adl110", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("pl110", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ca110", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ce110", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("plt110", System.Type.GetType("System.Double")));

                dtDataXml.Columns.Add(new DataColumn("len125", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("flw125", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("adl125", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("pl125", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ca125", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ce125", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("plt125", System.Type.GetType("System.Double")));

                dtDataXml.Columns.Add(new DataColumn("len160", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("flw160", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("adl160", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("pl160", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ca160", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ce160", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("plt160", System.Type.GetType("System.Double")));

                dtDataXml.Columns.Add(new DataColumn("len200", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("flw200", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("adl200", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("pl200", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ca200", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ce200", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("plt200", System.Type.GetType("System.Double")));

                dtDataXml.Columns.Add(new DataColumn("len250", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("flw250", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("adl250", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("pl250", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ca250", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("ce250", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("plt250", System.Type.GetType("System.Double")));

                dtDataXml.Columns.Add(new DataColumn("lblFrictionLoss", System.Type.GetType("System.Double")));
                dtDataXml.Columns.Add(new DataColumn("lblStaticFrictionLoss", System.Type.GetType("System.Double")));


                DataRow drDataXml = dtDataXml.NewRow();
                drDataXml["userId"] = UserId;
                drDataXml["ddlProject"] = Convert.ToInt64(ProjectID);
                drDataXml["ddlMainLine"] = Convert.ToInt64(ddlMainLine.SelectedValue);
                drDataXml["txtLength"] = Convert.ToDouble(txtLength.Text.Trim());

                drDataXml["len110"] = Convert.ToDouble(len110.Text.Trim());
                drDataXml["flw110"] = Convert.ToDouble(flw110.Text.Trim());
                drDataXml["adl110"] = Convert.ToDouble(adl110.Text.Trim());
                drDataXml["pl110"] = Convert.ToDouble(pl110.Text.Trim());
                drDataXml["ca110"] = Convert.ToDouble(ca110.Text.Trim());
                drDataXml["ce110"] = Convert.ToDouble(ce110.Text.Trim());
                drDataXml["plt110"] = Convert.ToDouble(plt110.Text.Trim());

                drDataXml["len125"] = Convert.ToDouble(len125.Text.Trim());
                drDataXml["flw125"] = Convert.ToDouble(flw125.Text.Trim());
                drDataXml["adl125"] = Convert.ToDouble(adl125.Text.Trim());
                drDataXml["pl125"] = Convert.ToDouble(pl125.Text.Trim());
                drDataXml["ca125"] = Convert.ToDouble(ca125.Text.Trim());
                drDataXml["ce125"] = Convert.ToDouble(ce125.Text.Trim());
                drDataXml["plt125"] = Convert.ToDouble(plt125.Text.Trim());

                drDataXml["len160"] = Convert.ToDouble(len160.Text.Trim());
                drDataXml["flw160"] = Convert.ToDouble(flw160.Text.Trim());
                drDataXml["adl160"] = Convert.ToDouble(adl160.Text.Trim());
                drDataXml["pl160"] = Convert.ToDouble(pl160.Text.Trim());
                drDataXml["ca160"] = Convert.ToDouble(ca160.Text.Trim());
                drDataXml["ce160"] = Convert.ToDouble(ce160.Text.Trim());
                drDataXml["plt160"] = Convert.ToDouble(plt160.Text.Trim());

                drDataXml["len200"] = Convert.ToDouble(len200.Text.Trim());
                drDataXml["flw200"] = Convert.ToDouble(flw200.Text.Trim());
                drDataXml["adl200"] = Convert.ToDouble(adl200.Text.Trim());
                drDataXml["pl200"] = Convert.ToDouble(pl200.Text.Trim());
                drDataXml["ca200"] = Convert.ToDouble(ca200.Text.Trim());
                drDataXml["ce200"] = Convert.ToDouble(ce200.Text.Trim());
                drDataXml["plt200"] = Convert.ToDouble(plt200.Text.Trim());

                drDataXml["len250"] = Convert.ToDouble(len250.Text.Trim());
                drDataXml["flw250"] = Convert.ToDouble(flw250.Text.Trim());
                drDataXml["adl250"] = Convert.ToDouble(adl250.Text.Trim());
                drDataXml["pl250"] = Convert.ToDouble(pl250.Text.Trim());
                drDataXml["ca250"] = Convert.ToDouble(ca250.Text.Trim());
                drDataXml["ce250"] = Convert.ToDouble(ce250.Text.Trim());
                drDataXml["plt250"] = Convert.ToDouble(plt250.Text.Trim());

                drDataXml["lblFrictionLoss"] = Convert.ToDouble(lblFrictionLoss.Text.Trim());
                drDataXml["lblStaticFrictionLoss"] = Convert.ToDouble(lblStaticFrictionLoss.Text.Trim());

                dtDataXml.Rows.Add(drDataXml);
                dsDataXML.Tables.Add(dtDataXml);

                string MainlineRequestXML = dsDataXML.GetXml();
                DataSet dsResult = mld.SaveUpdateMainlineRequest(MainlineRequestXML);
                string message = dsResult.Tables[0].Rows[0]["Status"].ToString();
                MessageDisplay(true, message);
            }
            catch (System.Exception ex)
            {
                Session["Exception"] = "Message: " + ex.Message + "~ Stack: " + ex.StackTrace;
                Response.Redirect("DefaultErrorPage.aspx", false);
            }





        }

        private void MessageDisplay(bool display, string message = "")
        {
            if (display)
            {
                mainlineSaveUpdateAlert.InnerText = message.ToString();
                mainlineSaveUpdateAlert.Style.Add("display", "block");
            }
            else
            {
                mainlineSaveUpdateAlert.Style.Add("display", "none");
            }
        }

        public void GetData()
        {
            DataSet ds = mld.getMainlineDataForUser(UserId, Convert.ToInt16(ProjectID), Convert.ToInt16(ddlMainLine.SelectedValue));
            if (ds != null && ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    txtLength.Text = ds.Tables[0].Rows[0][4].ToString();
                    txtLength_TextChanged("", null);
                    len110.Text = ds.Tables[0].Rows[0][5].ToString();
                    len110_TextChanged("", null);
                    flw110.Text = ds.Tables[0].Rows[0][6].ToString();
                    adl110.Text = ds.Tables[0].Rows[0][7].ToString();
                    pl110.Text = ds.Tables[0].Rows[0][8].ToString();
                    ca110.Text = ds.Tables[0].Rows[0][9].ToString();
                    ce110.Text = ds.Tables[0].Rows[0][10].ToString();
                    plt110.Text = ds.Tables[0].Rows[0][11].ToString();
                    len125.Text = ds.Tables[0].Rows[0][12].ToString();
                    len125_TextChanged("", null);
                    flw125.Text = ds.Tables[0].Rows[0][13].ToString();
                    adl125.Text = ds.Tables[0].Rows[0][14].ToString();
                    pl125.Text = ds.Tables[0].Rows[0][15].ToString();
                    ca125.Text = ds.Tables[0].Rows[0][16].ToString();
                    ce125.Text = ds.Tables[0].Rows[0][17].ToString();
                    plt125.Text = ds.Tables[0].Rows[0][18].ToString();
                    len160.Text = ds.Tables[0].Rows[0][19].ToString();
                    len160_TextChanged("", null);
                    flw160.Text = ds.Tables[0].Rows[0][20].ToString();
                    adl160.Text = ds.Tables[0].Rows[0][21].ToString();
                    pl160.Text = ds.Tables[0].Rows[0][22].ToString();
                    ca160.Text = ds.Tables[0].Rows[0][23].ToString();
                    ce160.Text = ds.Tables[0].Rows[0][24].ToString();
                    plt160.Text = ds.Tables[0].Rows[0][25].ToString();
                    len200.Text = ds.Tables[0].Rows[0][26].ToString();
                    len200_TextChanged("", null);
                    flw200.Text = ds.Tables[0].Rows[0][27].ToString();
                    adl200.Text = ds.Tables[0].Rows[0][28].ToString();
                    pl200.Text = ds.Tables[0].Rows[0][29].ToString();
                    ca200.Text = ds.Tables[0].Rows[0][30].ToString();
                    ce200.Text = ds.Tables[0].Rows[0][31].ToString();
                    plt200.Text = ds.Tables[0].Rows[0][32].ToString();
                    len250.Text = ds.Tables[0].Rows[0][33].ToString();
                    len125_TextChanged("", null);
                    flw250.Text = ds.Tables[0].Rows[0][34].ToString();
                    adl250.Text = ds.Tables[0].Rows[0][35].ToString();
                    pl250.Text = ds.Tables[0].Rows[0][36].ToString();
                    ca250.Text = ds.Tables[0].Rows[0][37].ToString();
                    ce250.Text = ds.Tables[0].Rows[0][38].ToString();
                    plt250.Text = ds.Tables[0].Rows[0][39].ToString();
                    lblFrictionLoss.Text = ds.Tables[0].Rows[0][40].ToString();
                    lblStaticFrictionLoss.Text = ds.Tables[0].Rows[0][41].ToString();
                }
                else
                {





                    txtLength.Text = "0";
                    len110.Text = "0";
                    len110_TextChanged("", null);
                    flw110.Text = "0";
                    adl110.Text = "0";
                    pl110.Text = "0";
                    ca110.Text = "0";
                    ce110.Text = "0";
                    plt110.Text = "0";
                    len125.Text = "0";
                    len125_TextChanged("", null);
                    flw125.Text = "0";
                    adl125.Text = "0";
                    pl125.Text = "0";
                    ca125.Text = "0";
                    ce125.Text = "0";
                    plt125.Text = "0";
                    len160.Text = "0";
                    len160_TextChanged("", null);
                    flw160.Text = "0";
                    adl160.Text = "0";
                    pl160.Text = "0";
                    ca160.Text = "0";
                    ce160.Text = "0";
                    plt160.Text = "0";
                    len200.Text = "0";
                    len200_TextChanged("", null);
                    flw200.Text = "0";
                    adl200.Text = "0";
                    pl200.Text = "0";
                    ca200.Text = "0";
                    ce200.Text = "0";
                    plt200.Text = "0";
                    len250.Text = "0";
                    len250_TextChanged("", null);
                    flw250.Text = "0";
                    adl250.Text = "0";
                    pl250.Text = "0";
                    ca250.Text = "0";
                    ce250.Text = "0";
                    plt250.Text = "0";
                    lblFrictionLoss.Text = "0";
                    lblStaticFrictionLoss.Text = "0";
                    ResetField();
                }
            }
        }

        protected void ddlProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetData();
        }

        protected void ddlMainLine_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetData();
        }
        protected void ResetField()
        {
            if (txtLength.Text == "0")
            {
                tl110.Text = "0";
                tl125.Text = "0";
                tl160.Text = "0";
                tl200.Text = "0";
                tl250.Text = "0";

            }
        }

        protected void GetProjectId()
        {
            // RedirectModal.Visible = false;
            if (System.Web.HttpContext.Current.Session["ProjectID"] != null)
            {

                ProjectID = Session["ProjectID"].ToString();

            }
            else
            {
                Response.Redirect("Default.aspx");
            }

        }
        protected void Redirect(object sender, EventArgs e)
        {
            Response.Redirect("default.aspx?returnUrl=MainlineCalculator.aspx");

        }
    }
}