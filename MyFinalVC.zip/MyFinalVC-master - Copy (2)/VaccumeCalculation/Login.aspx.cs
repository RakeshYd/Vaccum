﻿using System;
using System.Data;
using VaccumeCalculation.DAL;
namespace VaccumeCalculation
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object obj, EventArgs e)
        {
            login_alert.InnerText = "";
            login_alert.Style.Add("display", "none");
            DataSet ds = SignIn(txtUserID.Text, txtPassword.Text);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["UsDetails"] = ds;
                if (ds.Tables[0].Rows[0]["Project"].ToString() != "0")
                {
                    string redirectURL = (Request.QueryString["returnurl"]) == null ? "~/Default.aspx" : "~/" + Request.QueryString["returnurl"];
                    Response.Redirect(redirectURL);
                }
                else
                {
                    Response.Redirect("~/Project.aspx");
                }


            }
            else
            {
                login_alert.InnerText = "Enter correct credential or You don't have an account !";
                login_alert.Style.Add("display", "block");
            }

        }
        protected DataSet SignIn(string userId, string password)
        {
            LoginData ld = new LoginData();
            DataSet dsUser = ld.GetLogin(userId, password);
            return dsUser;
        }
        protected void Unnamed_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/SignUp.aspx");
        }
    }
}