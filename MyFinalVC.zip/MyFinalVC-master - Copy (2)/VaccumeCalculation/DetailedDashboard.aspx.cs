﻿using System;
using System.Data;
using System.Text;
using System.Web;
using System.Web.UI.WebControls;
using VaccumeCalculation.DAL;


namespace VaccumeCalculation
{
    public partial class DetailedDashboard : System.Web.UI.Page
    {
        Int32 UserId = 0;
        MasterData md = new MasterData();
        MainlineData mld = new MainlineData();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                adminViewSpan.Visible = false;
                UserDetails("Dashboard");
                GetProjectDetails();
                DataSet ds = (DataSet)(Session["UsDetails"]);
                string isAdmin = ds.Tables[0].Rows[0]["Role"].ToString();
                if (isAdmin.ToLower() == "admin")
                {
                    adminViewSpan.Visible = true;
                }
                DataSet dsMainLineData = mld.getMainlineData(Convert.ToInt32(Session["ProjectID"]), UserId);
                // GenerateTable(dsMainLineData);
                BindGrids(dsMainLineData);
                BindAllUsers();
                BindProject(Convert.ToInt16(ddlUsers.SelectedValue));
            }

        }

        private void BindGrids(DataSet ds)
        {
            if (ds != null && ds.Tables.Count > 0)
            {
                if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    gvMainline.DataSource = ds.Tables[0];
                    gvMainline.DataBind();
                }
                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                {
                    gvPeakFlow.DataSource = ds.Tables[1];
                    gvPeakFlow.DataBind();
                }
                if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                {
                    gvRisingMain.DataSource = ds.Tables[2];
                    gvRisingMain.DataBind();
                }
                if (ds.Tables[3] != null && ds.Tables[3].Rows.Count > 0)
                {
                    gvVacuumStation.DataSource = ds.Tables[3];
                    gvVacuumStation.DataBind();
                }
                if (ds.Tables[4] != null && ds.Tables[4].Rows.Count > 0)
                {
                    gvSideBranch.DataSource = ds.Tables[4];
                    gvSideBranch.DataBind();
                }

            }





        }

        private void GetProjectDetails()
        {
            if (System.Web.HttpContext.Current.Session["ProjectID"] != null)
            {
                DataSet ds = md.GetProjectDetails(Convert.ToInt32(Session["ProjectID"].ToString()));
                if (ds != null && ds.Tables.Count > 0)
                {
                    lblPojectDesceiption.Text = ds.Tables[0].Rows[0][0].ToString();
                }


            }
        }

        private void UserDetails(string returnURL)
        {
            if (HttpContext.Current == null || HttpContext.Current.Session == null || HttpContext.Current.Session["UsDetails"] == null)
            {
                Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
            }
            else
            {
                DataSet ds = (DataSet)(Session["UsDetails"]);
                LinkButton btnUser = this.Master.FindControl("loginName") as LinkButton;
                LinkButton btnLogout = this.Master.FindControl("logOut") as LinkButton;
                LinkButton btnLoginLink = this.Master.FindControl("loginLink") as LinkButton;
                if (ds != null && ds.Tables.Count > 0)
                {
                    btnLoginLink.Visible = false;
                    btnUser.Text = "Welcome, " + ds.Tables[0].Rows[0]["FirstName"].ToString() + " !  ";
                    btnUser.Visible = true;
                    btnLogout.Text = "LogOut";
                    btnLogout.Visible = true;
                    if (!IsPostBack)
                    {
                        UserId = Convert.ToInt16(ds.Tables[0].Rows[0]["UserID"]);
                    }

                }
                else
                {
                    Response.Redirect("~/login.aspx?returnurl=" + returnURL + ".aspx");
                }
            }
        }

        private void GenerateTable(DataSet dsResult)
        {
            if (dsResult != null)
            {
                for (int i = 0; i < dsResult.Tables.Count; i++)
                {
                    LoadDataInTable(dsResult.Tables[i]);
                }
            }
        }

        private void LoadDataInTable(DataTable dt)
        {

            //Building an HTML string.
            StringBuilder html = new StringBuilder();

            //add panel
            html.Append("<div class=\"panel panel-default\"> <div class=\"panel-heading\">");

            //heading 
            html.Append("<h4>" + GetHeader(dt.TableName.Trim()) + "</h4>");

            //heading closed
            html.Append("</div>");

            //body
            html.Append("<div class=\"panel-body\">");

            //Table start.
            html.Append("<table class=\"table table - hover table - striped\" >");

            //Building the Header row.
            html.Append(" <thead>");
            foreach (DataColumn column in dt.Columns)
            {
                html.Append("<th>");
                html.Append(column.ColumnName);
                html.Append("</th>");
            }
            html.Append("</tr></thead>");

            //Building the Data rows.
            foreach (DataRow row in dt.Rows)
            {
                html.Append("<tbody><tr>");
                foreach (DataColumn column in dt.Columns)
                {
                    html.Append("<td>");
                    html.Append(row[column.ColumnName]);
                    html.Append("</td>");
                }
                html.Append("</tr></tbody>");
            }

            html.Append("</table>");

            html.Append("</div></div>");

            //Append the HTML string to Placeholder.
            //tablePlaceHolder.Controls.Add(new Literal { Text = html.ToString() });
        }

        protected DataTable GetAllUsers()
        {

            DataSet dsUsers = md.GetAllUsers();
            return dsUsers.Tables[0];
        }

        protected DataSet GetAllProject(int userID)
        {
            return md.GetAllProject(userID);

        }

        protected void BindProject(int userID)
        {
            DataSet dsProject = GetAllProject(userID);
            ddlProject.DataSource = dsProject.Tables[0];
            ddlProject.DataTextField = "Project";
            ddlProject.DataValueField = "ID";
            ddlProject.DataBind();
            ddlProject.Items.Insert(0, new ListItem("---Select---", "0"));
        }

        protected void BindAllUsers()
        {
            ddlUsers.DataSource = GetAllUsers();
            ddlUsers.DataTextField = "FullName";
            ddlUsers.DataValueField = "ID";
            ddlUsers.DataBind();

        }

        protected void ddlUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddl = sender as DropDownList;
            BindProject(Convert.ToInt16(ddl.SelectedValue));
        }

        protected void ddlProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet dsMainLineData = mld.getMainlineData(Convert.ToInt16(ddlProject.SelectedValue), Convert.ToInt16(ddlUsers.SelectedValue));
            GenerateTable(dsMainLineData);
        }

        private string getUrl(int index)
        {
            int value = index;
            string retrunValue = "";
            switch (value)
            {
                case 1:
                    retrunValue = "MainlineCalulator.aspx";
                    break;
                case 2:
                    retrunValue = "PeakFlowCalucation.aspx";
                    break;
                case 3:
                    retrunValue = "RisingMain.aspx";
                    break;
                default:
                    retrunValue = "MainlineCalulator.aspx";
                    break;
            }
            return retrunValue;
        }

        private string GetHeader(string tableName)
        {
            string returnValue = string.Empty;
            string val = tableName;
            switch (val)
            {
                case "Table":
                    returnValue = "Main Line";
                    break;
                case "Table1":
                    returnValue = "Peak Flow";
                    break;
                case "Table2":
                    returnValue = "Rising Main";
                    break;
                case "Table3":
                    returnValue = "Vacuum Station";
                    break;
                case "Table4":
                    returnValue = "Side Branch";
                    break;

                default:
                    returnValue = "";
                    break;
            }
            return returnValue;
        }


        protected void gvMainline_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName == "MainLineEdit")
            {
                int MainLineRowId = Convert.ToInt32(e.CommandArgument);
                AddSession(MainLineRowId, "MainLineRowId");
                Response.Redirect("MainlineCalculator.aspx", false);
            }

        }

        protected void gvPeakFlow_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "PeakFlowEdit")
            {
                int PeakFlowRowId = Convert.ToInt32(e.CommandArgument);
                AddSession(PeakFlowRowId, "PeakFlowRowId");
                Response.Redirect("PeakFlowCalculation.aspx", false);
            }

        }

        protected void gvRisingMain_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "RisingMainEdit")
            {
                int RisingMainRowID = Convert.ToInt32(e.CommandArgument);
                AddSession(RisingMainRowID, "RisingMainRowID");
                Response.Redirect("Risingmain.aspx", false);
            }

        }

        protected void gvVacuumStation_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "VacuumStationEdit")
            {
                int VacuumStationRowID = Convert.ToInt32(e.CommandArgument);
                AddSession(VacuumStationRowID, "VacuumStationRowID");
                Response.Redirect("TanksAndPumps.aspx", false);
            }

        }
        protected void gvSideBranch_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "SideBranchEdit")
            {
                int SideBranchRowID = Convert.ToInt32(e.CommandArgument);
                AddSession(SideBranchRowID, "SideBranchRowID");
                Response.Redirect("SideLine.aspx", false);
            }

        }
        private void AddSession(int rowID, string rowIDName)
        {
            if (System.Web.HttpContext.Current.Session[rowIDName] != null)
            {
                Session.Remove(rowIDName);
                Session[rowIDName] = rowID.ToString();

            }
            else
            {
                Session[rowIDName] = rowID.ToString();
            }

        }

    }
}